package DomainInventory;

public class Contact {
    private String name;
    private String phone;

    // Constructor - Initializes a new Contact with a name and a phone number.
    public Contact(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }
    // Returns the name of the contact.
    public String getName() {return name;}

    // Sets a new name for the contact.
    public void setName(String name) {this.name = name;}

    // Returns the phone number of the contact.
    public String getPhone() {return phone;}

    // Sets a new phone number for the contact.
    public void setPhone(String phone) {this.phone = phone;}

}
