package PresentationInventory;

import DomainInventory.Discount;
import DomainInventory.Order;
import DomainInventory.Product;
import ServiceInventory.OrderService;
import ServiceInventory.SupplierService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class OrderUI {
    private final OrderService orderService;
    private final SupplierService supplierService;
    static Scanner scanner = new Scanner(System.in);

    // Constructor to initialize the OrderUI with necessary services
    public OrderUI(OrderService orderService, SupplierService supplierService) {
        this.orderService = orderService;
        this.supplierService = supplierService;
    }

    // Main menu for managing orders
    public void manageOrder() {
        boolean run = true;
        while (run) {
            System.out.println("Welcome to the order manager: ");
            System.out.println("1. Create a new order");
            System.out.println("2. Edit products in order");
            System.out.println("3. Check/change order status");
            System.out.println("4. Delete open order");
            System.out.println("5. View order details by ID");
            System.out.println("6. View all active orders");
            System.out.println("7. Price offers on product");
            System.out.println("8. Submit order");
            System.out.println("9. Back to main menu");

            int choice = ViewManger.promptMenuChoice(8);
            switch (choice) {
                case 1 -> createNewOrder();
                case 2 -> editProductsInOrderFlow();
                case 3 -> changeOrderStatusFlow();
                case 4 -> deleteOrderFlow();
                case 5 -> viewOrderDetails();
                case 6 -> viewAllActiveOrders();
                case 7 -> viewProductOffers();
                case 8 -> run = false;
            }
        }
    }

    // Creates a new order with input validations
    private void createNewOrder() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        System.out.println("Enter Contact Phone Number:");
        String contactPhoneNumber = scanner.nextLine();
        while (contactPhoneNumber.length() != 10) {
            System.out.println("Contact phone number must be 10 digits. Try again:");
            contactPhoneNumber = scanner.nextLine();
        }
        int newOrderID = orderService.createNewOrder(supplierID, contactPhoneNumber);
        System.out.println("Order " + newOrderID + " was successfully added.");
        System.out.print("Would you like to add products to the order? (yes/no): ");
        String answer = scanner.nextLine().trim();
        while (!answer.equalsIgnoreCase("yes") && !answer.equalsIgnoreCase("no")) {
            System.out.print("Invalid input. Please type 'yes' or 'no': ");
            answer = scanner.nextLine().trim();
        }
        if (answer.equalsIgnoreCase("yes")) {
            editProductsInOrder(newOrderID,supplierID);
        } else {
            System.out.println("The order is saved and waiting.");
        }
    }

    // Handles editing products in an existing order
    private void editProductsInOrderFlow() {
        int orderID = ViewManger.promptForInt("Enter Order ID:");
        if (orderService.checkIfOrderExists(orderID)) {
            System.out.println("There is no such order in the system.");
            return;
        }
        editProductsInOrder(orderID,orderService.getSupplierIDinOrder(orderID));
    }

    // Handles changing the status of an order
    private void changeOrderStatusFlow() {
        int orderID = ViewManger.promptForInt("Enter Order ID:");
        if (orderService.checkIfOrderExists(orderID)) {
            System.out.println("There is no such order in the system.");
            return;
        }
        if (orderService.checkOrderStatus(orderID)) {
            System.out.println("Order: " + orderID + " is completed.");
            return;
        }
        System.out.println("Order: " + orderID + " is waiting.");
        System.out.print("Would you like to change the order status? (yes/no): ");
        String answer = scanner.nextLine().trim();
        if (answer.equalsIgnoreCase("yes")) {
            orderService.changeOrderStatus(orderID);
            System.out.println("Order status changed.");
        }
    }

    // Handles deleting an order
    private void deleteOrderFlow() {
        int orderID = ViewManger.promptForInt("Enter Order ID:");
        if (orderService.checkIfOrderExists(orderID)) {
            System.out.println("There is no such order in the system.");
            return;
        }
        if (orderService.checkOrderStatus(orderID)) {
            System.out.println("You can't delete a completed order.");
            return;
        }
        orderService.deleteOrder(orderID);
        System.out.println("Order deleted successfully.");
    }

    // Displays details of a specific order
    private void viewOrderDetails() {
        int orderID = ViewManger.promptForInt("Enter Order ID:");
        if (orderService.checkIfOrderExists(orderID)) {
            System.out.println("There is no such order in the system.");
            return;
        }
        System.out.println(orderService.getOrder(orderID));
    }

    // Displays all active orders
    private void viewAllActiveOrders() {
        ArrayList<Order> activeOrders = orderService.getActiveOrders();
        if (activeOrders.isEmpty()) {
            System.out.println("No active orders found.");
        } else {
            System.out.println("Active Orders:");
            for (Order order : activeOrders) {
                System.out.println(order);
            }
        }
    }

    // Displays all offers for a given product
    private void viewProductOffers() {
        System.out.println("Enter product ID:");
        int productID = scanner.nextInt();
        scanner.nextLine(); // Consume leftover newline
        printProductOptions(productID);
    }

    // Prints product options and available discounts
    public void printProductOptions(int productID) {
        HashMap<Product, Discount> options = orderService.getProductOptions(productID);

        if (options.isEmpty()) {
            System.out.println("No product options found for product ID: " + productID);
        } else {
            System.out.println("Product options for product ID: " + productID + ":");
            for (HashMap.Entry<Product, Discount> entry : options.entrySet()) {
                Product product = entry.getKey();
                Discount discount = entry.getValue();
                System.out.println(product);
                if (discount != null) {
                    System.out.println("  Discount available:");
                    System.out.println(discount);
                } else {
                    System.out.println("  No discount available for this supplier.");
                }
            }
        }
    }

    // Edits products inside an order, either adds a new product or edits an existing one
    public void editProductsInOrder(int orderID,int supplierID) {
        int productID = ViewManger.promptForInt("Enter product ID:");
        if(!supplierService.checkIfProductExist(supplierID,productID)){
            System.out.println("There is no such Product in the System");
            return;
        }
        if(!orderService.CheckIfProductAndOrderTypesEquals(orderID,productID)){
            System.out.println("The Product is in agreement that did not match to: " + orderService.getOrderType(orderID));
        }

        if(orderService.checkIfProductExists(productID,orderID)){
            editExistingProductsInOrder(orderID,productID);
            return;
        }
        System.out.println("Please choose an option:");
        System.out.println("1. Price offers on product");
        System.out.println("2. Add product to order");
        System.out.println("3. Exit");
        int choice = ViewManger.promptMenuChoice(3);
        switch (choice) {
            case 1 -> showProductsPrices(productID);
            case 2 -> {
                int quantity = ViewManger.promptForInt("Enter quantity:");
                orderService.addProductToOrder(productID, quantity, orderID);
                System.out.println("The product: " + productID + " with quantity of: " + quantity + " has been added.");
                System.out.println("The updated order price is: " + orderService.getOrderTotalPrice(orderID) + "₪");
            }
            case 3 -> {}
        }
    }

    // Handles editing an existing product in the order
    public void editExistingProductsInOrder(int orderID,int productID) {
        System.out.println("The item is in the order, please choose an option:");
        System.out.println("1. Delete product from order");
        System.out.println("2. Change quantity");
        System.out.println("3. Get item quantity");
        System.out.println("4. Exit");
        int choice = ViewManger.promptMenuChoice(4);
        switch (choice) {
            case 1 -> {
                orderService.deleteProductFromOrder(productID, orderID);
                System.out.println("The product: " + productID + " removed.");
                System.out.println("The updated order price is: " + orderService.getOrderTotalPrice(orderID) + "₪");
            }
            case 2 -> {
                int quantity = ViewManger.promptForInt("Insert quantity:");
                orderService.changeProductQuantity(productID, quantity, orderID);
                System.out.println("The product: " + productID + " quantity has been changed to: " + quantity + " in order: " + orderID + ".");
                System.out.println("The updated order price is: " + orderService.getOrderTotalPrice(orderID) + "₪");
            }
            case 3 -> System.out.println("The product: " + productID + " quantity is: " + orderService.getProductQuantity(productID, orderID));
            case 4 -> {}
        }
    }

    // Helper method to show product prices
    private void showProductsPrices(int productID) {
        printProductOptions(productID);
    }
}
