package Data;

public class Category {
    //Fields
    private final String categoryName;
    private final int rank;

    //Constructor
    public Category(String categoryName_, int rank_){
        //assuming valid inputs
        this.categoryName = categoryName_;
        this.rank = rank_;
    }

    //Functions
    public String getName(){return categoryName;}
    public int getRank(){ return rank;};
}
