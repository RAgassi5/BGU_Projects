package ServiceTests;

import ServiceInventory.OrderService;
import DomainInventory.*;
import DataInventory.*;
import ServiceInventory.SupplierService;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class OrderTest {
    private IOrderRepository orderRepo = new OrderRepository();
    private IProductRepository productRepo = new ProductRepository();
    private ISupplierRepository supplierRepo = new SupplierRepository();
    private SupplierService supplierService = new SupplierService(productRepo, supplierRepo);
    private OrderService orderService = new OrderService(orderRepo, productRepo, supplierRepo,supplierService);
    @Test
    void testCreateNewOrder_success() {
        // Check creating a new order
        int orderID = orderService.createNewOrder(1, "0501234567");

        assertFalse(orderService.checkIfOrderExists(orderID));
    }

    @Test
    void testAddProductToOrder_success() {
        // Check adding a product to an existing order


        Supplier supplier = new Supplier("Supplier1", "12345678");
        supplierRepo.insertSupplier(supplier);
        Product product = new Product(1000, 40.0, supplier.getSupplierID(), "Tomato", "FactoryA", "Food");
        productRepo.addProductToRepo(product);

        int orderID = orderService.createNewOrder(supplier.getSupplierID(), "0509876543");
        orderService.addProductToOrder(product.getProductID(), orderID, 3);

        assertTrue(orderService.checkIfProductExists(product.getProductID(), orderID));
    }

    @Test
    void testChangeOrderStatus() {
        // Check changing the status of an order

        int orderID = orderService.createNewOrder(2, "0505555555");

        assertFalse(orderService.checkOrderStatus(orderID));

        orderService.changeOrderStatus(orderID);

        assertTrue(orderService.checkOrderStatus(orderID));
    }

    @Test
    void testDeleteOrder_success() {
        // Check deleting an existing order


        int orderID = orderService.createNewOrder(3, "0506666666");

        orderService.deleteOrder(orderID);

        assertTrue(orderService.checkIfOrderExists(orderID));
    }

    @Test
    void testChangeProductQuantity_success() {
        // Check changing quantity of a product in an order


        Supplier supplier = new Supplier("Supplier2", "87654321");
        supplierRepo.insertSupplier(supplier);
        Product product = new Product(1001, 25.0, supplier.getSupplierID(), "Milk", "FactoryB", "Drink");
        productRepo.addProductToRepo(product);

        int orderID = orderService.createNewOrder(supplier.getSupplierID(), "0507777777");
        orderService.addProductToOrder(product.getProductID(), orderID, 2);

        orderService.changeProductQuantity(product.getProductID(), 5, orderID);

        assertEquals(5, orderService.getProductQuantity(product.getProductID(), orderID));
    }

    @Test
    void testGetOrderTotalPrice() {
        // Check calculating total price of the order


        Supplier supplier = new Supplier("Supplier3", "11223344");
        supplierRepo.insertSupplier(supplier);
        Product product = new Product(1002, 10.0, supplier.getSupplierID(), "Juice", "FactoryC", "Drink");
        productRepo.addProductToRepo(product);

        int orderID = orderService.createNewOrder(supplier.getSupplierID(), "0508888888");
        orderService.addProductToOrder(product.getProductID(), orderID, 3);

        assertEquals(30.0, orderService.getOrderTotalPrice(orderID));
    }

    @Test
    void testDeleteProductFromOrder() {
        // Check removing a product from an order


        Supplier supplier = new Supplier("Supplier4", "55667788");
        supplierRepo.insertSupplier(supplier);
        Product product = new Product(1003, 70.0, supplier.getSupplierID(), "Shampoo", "FactoryD", "Cleaning");
        productRepo.addProductToRepo(product);

        int orderID = orderService.createNewOrder(supplier.getSupplierID(), "0509999999");
        orderService.addProductToOrder(product.getProductID(), orderID, 1);

        orderService.deleteProductFromOrder(product.getProductID(), orderID);

        assertFalse(orderService.checkIfProductExists(product.getProductID(), orderID));
    }


    @Test
    void testChangeOrderStatus_invalidOrder_shouldNotCrash() {
        // Check changing status for a non-existing order


        // No order created yet with ID 9999
        assertThrows(NullPointerException.class, () -> orderService.changeOrderStatus(9999));
    }

    @Test
    void testAddSameProductTwice_shouldRejectSecond() {
        // Check that the same product cannot be added twice to the same order

        Supplier supplier = new Supplier("Supplier5", "12345678");
        supplierRepo.insertSupplier(supplier);
        Product product = new Product(1005, 40.0, supplier.getSupplierID(), "Coke", "FactoryA", "Drink");
        productRepo.addProductToRepo(product);

        int orderID = orderService.createNewOrder(supplier.getSupplierID(), "0505555555");
        orderService.addProductToOrder(product.getProductID(), orderID, 2);

        // Try to add the same product again
        orderService.addProductToOrder(product.getProductID(), orderID, 3);

        // Quantity should stay as originally added (not increased)
        assertEquals(2, orderService.getProductQuantity(product.getProductID(), orderID));
    }

}
