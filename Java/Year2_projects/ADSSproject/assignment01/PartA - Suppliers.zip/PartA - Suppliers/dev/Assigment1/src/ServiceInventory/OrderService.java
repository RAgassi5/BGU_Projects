package ServiceInventory;

import DataInventory.*;
import DomainInventory.*;

import java.util.ArrayList;
import java.util.HashMap;

public class OrderService {
    private IOrderRepository orderRepo ;
    private IProductRepository productRepo;
    private SupplierService supplierService;

    // Constructor that initializes the OrderService with repositories for orders, products, and suppliers.
    public OrderService(IOrderRepository orderRepo, IProductRepository productRepo, ISupplierRepository supplierRepo, SupplierService supplierService) {
        this.orderRepo = orderRepo;
        this.productRepo = productRepo;
        this.supplierService = supplierService;
    }

    // Creates a new order for a given supplier with a contact phone number, stores it in the repository, and returns the new order ID.
    public int createNewOrder(int supplierID,String contactPhoneNumber) {
        Order order = new Order(supplierID,contactPhoneNumber);
        orderRepo.addOrderToRepository(order);
        return order.getOrderID();
    }
    // Checks if an order with the given ID exists in the repository.
    // Returns true if the order does NOT exist.
    public boolean checkIfOrderExists(int orderID) {
        return orderRepo.pollOrder(orderID) == null;
    }
    // Returns the status of the order (true if completed, false if in progress).
    public boolean checkOrderStatus(int orderID) {
        return orderRepo.getOrderStatus(orderID);
    }
    // Changes the status of the order with the given ID to 'completed'.
    public void changeOrderStatus(int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        order.setOrderStatus();
    }
    // Deletes the order with the given ID from the repository.
    public void deleteOrder(int orderID) {
        orderRepo.deleteOrderFromRepo(orderID);
    }
    // Displays the details of the order with the given ID by printing them.
    public Order getOrder(int orderID) {
        return orderRepo.pollOrder(orderID);
    }

    // Returns a list of all active orders from the repository.
    public ArrayList<Order> getActiveOrders(){
        return orderRepo.getAllActiveOrders();
    }

    // Checks if a specific product exists in a given order.
    public boolean checkIfProductExists(int productID,int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        return order.checkIfProductInList(productID);
    }

    // Changes the quantity of a specific product in a given order.
    public void changeProductQuantity(int productID, int quantity,int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        order.editItemQuantity(quantity,productID);
    }

    // Returns the total price of a given order.
    public double getOrderTotalPrice(int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        return (order.getOrderPrice());
    }

    // Removes a product from a given order.
    public void deleteProductFromOrder(int productID, int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        order.removeProductFromOrder(productID);
    }

    // Returns the quantity of a specific product in a given order.
    public int getProductQuantity(int productID, int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        return order.getProductQuantity(productID);
    }

    // Adds a product with a specific quantity to a given order.
    public void addProductToOrder(int productID, int orderID, int quantity) {
        Order order = orderRepo.pollOrder(orderID);
        Product product = productRepo.getProductByPSId(productID,order.getOrderSupplierID());
        Discount discount =supplierService.getSupplierProductDiscount(product.getSupplierID(),product.getCatalogID());
        if(discount != null)
            order.addProductToOrder(product,quantity,discount.getDiscountedPrice());
        order.addProductToOrder(product,quantity,product.getPrice());
    }

    // Returns a map of Products and their corresponding Discounts (if any) for a given product ID.
    public HashMap<Product, Discount>  getProductOptions(int productID) {
        HashMap<Product, Discount> productsWithDiscount = new HashMap<>();
        for (Product product : productRepo.getProductByProductId(productID).values())
                productsWithDiscount.put(product,supplierService.getSupplierProductDiscount(product.getSupplierID(),product.getCatalogID()));
        return productsWithDiscount;
    }
    //Retrieves the supplier ID associated with a given order.
    public int getSupplierIDinOrder(int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        return order.getOrderSupplierID();
    }
    //Checks if the product type matches the order type for a given order and product.
    public boolean CheckIfProductAndOrderTypesEquals(int orderID,int productID) {
        Order order = orderRepo.pollOrder(orderID);
        Product product = productRepo.getProductByPSId(productID,order.getOrderSupplierID());
        return( order.getOrderType() == product.getProductType() || product.getProductType()!=null || order.getOrderType() !=null);
    }
    //Retrieves the type of a given order.
    public String getOrderType(int orderID) {
        Order order = orderRepo.pollOrder(orderID);
        return order.getOrderType();
    }

}
