package ServiceTests;
import ServiceInventory.SupplierService;
import DomainInventory.*;
import DataInventory.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SupplierTest {

    @Test
    void testCreateSupplierAndCheckExistence() {
        // Check creating a supplier and if it exists
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);
        int supplierID = supplierService.createSupplier("Supplier1", "12345678");
        assertTrue(supplierService.doesSupplierExist(supplierID));
    }

    @Test
    void testAddProductToSupplier_success() {
        // Check adding a product to a supplier
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier2", "87654321");
        Product product = new Product(1000, 50.0, supplierID, "Tomatoes", "FactoryA", "Food");

        supplierService.addProductToSupplier(supplierID, product, "Food", "FactoryA");

        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        assertNotNull(supplier.getProduct(product.getCatalogID()));
    }

    @Test
    void testChangeSupplierStatus() {
        // Check changing supplier active status
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier3", "11223344");
        assertTrue(supplierService.checkSupplierStatus(supplierID));

        supplierService.changeStatusService(supplierID);
        assertFalse(supplierService.checkSupplierStatus(supplierID));
    }

    @Test
    void testAddContactToSupplier() {
        // Check adding a contact to a supplier
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier4", "55667788");
        supplierService.addContactToSupplier(supplierID, "John Doe", "0501234567");

        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        assertEquals(1, supplier.getContactDetails().size());
    }

    @Test
    void testCreatePickUpAgreement() {
        // Check creating a PickUp agreement for a supplier
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier5", "44556677");
        int agreementID = supplierService.CreatePickUpAgreement("Cash", supplierID, "Pickup Address");

        assertNotEquals(-1, agreementID);
    }

    @Test
    void testAddNewProductToAgreement_success() {
        // Check adding a product to a supplier and agreement
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier6", "99887766");
        int agreementID = supplierService.CreatePickUpAgreement("Credit", supplierID, "Main Street");

        Product product = supplierService.addNewProductToAgreement(1001, 40.0, supplierID, "Juice", agreementID, "FactoryB", "Drink");

        assertNotNull(product);
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        assertTrue(supplier.getProductsMap().containsKey(product.getCatalogID()));
    }

    @Test
    void testDeleteProductFromSystem() {
        // Check deleting a product from the supplier and system
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier7", "33445566");
        int agreementID = supplierService.CreatePickUpAgreement("Cash", supplierID, "Warehouse");

        Product product = supplierService.addNewProductToAgreement(1002, 60.0, supplierID, "Milk", agreementID, "FactoryC", "Food");

        supplierService.deleteProductFromSystem(product.getCatalogID(), agreementID, supplierID);

        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        assertNull(supplier.getProduct(product.getCatalogID()));
    }

    @Test
    void testAddDiscountedProduct_success() {
        // Check adding a discount to a product inside an agreement
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier8", "66778899");
        int agreementID = supplierService.CreatePickUpAgreement("Cash", supplierID, "Depot");

        Product product = supplierService.addNewProductToAgreement(1003, 70.0, supplierID, "Beer", agreementID, "FactoryA", "Drink");

        supplierService.addDiscountedProduct(product.getCatalogID(), 10, agreementID, supplierID, 5);

        Agreement agreement = supplierRepo.pullSupplier(supplierID).findAgreement(agreementID);
        assertNotNull(agreement.getProductDiscount(product.getCatalogID()));
    }

    @Test
    void testChangeAgreementStatus() {
        // Check changing agreement status (active/inactive)
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("Supplier9", "77889900");
        int agreementID = supplierService.CreatePickUpAgreement("Cash", supplierID, "Branch");

        Agreement agreement = supplierRepo.pullSupplier(supplierID).findAgreement(agreementID);
        boolean before = agreement.getAgreementStatus();

        supplierService.changeAgreementStatus(agreementID, supplierID);
        boolean after = agreement.getAgreementStatus();

        assertNotEquals(before, after);
    }

    @Test
    void testAddDiscountedProductToNonExistingProduct_shouldFailGracefully() {
        // Try adding discount to a non-existing product in agreement
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("SupplierInvalid2", "22222222");
        int agreementID = supplierService.CreatePickUpAgreement("Cash", supplierID, "Depot X");

        assertDoesNotThrow(() -> supplierService.addDiscountedProduct(9999, 10, agreementID, supplierID, 5));
    }


    @Test
    void testChangeAgreementStatus_invalidAgreement_shouldNotCrash() {
        // Try changing the status of an agreement that doesn't exist
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);

        int supplierID = supplierService.createSupplier("SupplierInvalid4", "44444444");

        // Try changing status of non-existing agreement
        assertThrows(NullPointerException.class, () -> supplierService.changeAgreementStatus(9999, supplierID));
    }

}
