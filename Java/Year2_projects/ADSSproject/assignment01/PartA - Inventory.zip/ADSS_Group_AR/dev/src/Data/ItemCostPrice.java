package Data;

import java.time.LocalDate;

public class ItemCostPrice {
    //Fields
    private final double costPrice;
    private final LocalDate startDate;
    private LocalDate endDate;
    private final int amount;

    //Constructor
    public ItemCostPrice(double costPrice,LocalDate startDate, LocalDate endDate, int amount){
        this.costPrice = costPrice;
        this.startDate = startDate;
        this.endDate = endDate;
        this.amount =amount;
    }

    //Functions
    public double getCP(){return costPrice;}

    public LocalDate getStartDate(){return this.startDate;}

    public LocalDate getEndDate(){return this.endDate;}

    public int getAmount() {return this.amount;}

    public Status setEndDate(LocalDate eDate) {
        if (eDate.isBefore(this.startDate))
                return Status.Failure;
        this.endDate = eDate;
        return Status.Success;
    }
}
