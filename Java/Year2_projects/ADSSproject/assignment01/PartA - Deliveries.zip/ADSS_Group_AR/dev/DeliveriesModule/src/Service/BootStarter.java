package Service;

import Domain.District;
import Domain.Location;
import Domain.Product;
import Domain.Shipment;

import java.time.LocalDate;

public class BootStarter {
    private DriversManager driversManager;
    private BookingSystem bookingSystem;
    private VehiclesManager vehiclesManager;

    public BootStarter() {
        this.bookingSystem = BookingSystem.getInstance();
        this.vehiclesManager = VehiclesManager.getInstance();
        this.driversManager = DriversManager.getInstance();

    }
    public void start() {
        this.driversManager.addDriver("David");
        this.driversManager.setDriverLicense("David", "Truck");
        this.driversManager.setDriverLicense("David", "Van");

        this.driversManager.addDriver("Shlomi");
        this.driversManager.setDriverLicense("Shlomi", "Truck");

        this.driversManager.addDriver("Lina");
        this.driversManager.setDriverLicense("Lina", "Van");

        this.driversManager.addDriver("Omer");
        this.driversManager.setDriverLicense("Omer", "Truck");
        this.driversManager.setDriverLicense("Omer", "Van");

        this.driversManager.addDriver("Tal");
        this.driversManager.setDriverLicense("Tal", "Van");

        this.driversManager.addDriver("Noa");
        this.driversManager.setDriverLicense("Noa", "Van");

        this.driversManager.addDriver("Eli");
        this.driversManager.setDriverLicense("Eli", "Truck");

        this.driversManager.addDriver("Dana");
        this.driversManager.setDriverLicense("Dana", "Truck");
        this.driversManager.setDriverLicense("Dana", "Van");

        // Setup Vehicles
        this.vehiclesManager.addVehicle("Truck", 2023345);
        this.vehiclesManager.addVehicle("Van", 129990);
        this.vehiclesManager.addVehicle("Truck", 2025555);
        this.vehiclesManager.addVehicle("Van", 930055);
        this.vehiclesManager.addVehicle("Van", 165401);
        this.vehiclesManager.addVehicle("Truck", 2026666);
        this.vehiclesManager.addVehicle("Van", 136679);
        this.vehiclesManager.addVehicle("Van", 340903);

        // Setup Shipments
        LocalDate date1 = LocalDate.of(2025, 6, 21);
        LocalDate date2 = LocalDate.of(2025, 6, 23);
        LocalDate date3 = LocalDate.of(2025, 7, 12);
        LocalDate date4 = LocalDate.of(2025, 6, 1);

        Location origin1 = new Location("John", "0549982030", "Rager St.", 21, District.South);
        Location origin2 = new Location("Reggie", "05233345065", "Weingate St.", 120, District.North);
        Location origin3 = new Location("Tom", "0501112233", "Ben Gurion St.", 10, District.Central);
        Location origin4 = new Location("Nina", "0502223344", "Herzl St.", 50, District.South);

        Location dest1 = new Location("Luke", "05235567065", "Dizengof St.", 35, District.South);
        Location dest2 = new Location("Mia", "050321445065", "5th Ave.", 3, District.North);
        Location dest3 = new Location("Lea", "0547778899", "Allenby St.", 15, District.Central);
        Location dest4 = new Location("Ben", "0506667788", "Begin St.", 42, District.South);

        Shipment one = new Shipment(origin1, dest1, date1);
        Shipment two = new Shipment(origin2, dest2, date2);
        Shipment three = new Shipment(origin3, dest3, date3);
        Shipment four = new Shipment(origin4, dest4, date4);

        // Add products to Shipment One
        Product p1 = new Product("Apples", 1, 2);
        Product p2 = new Product("Meat", 1, 10);
        Product p3 = new Product("Bananas", 1, 2);
        Product p4 = new Product("Watermelons", 5, 15);
        Product p5 = new Product("Cheese", 2, 4);
        one.addProductToShipment(p1, 10);
        one.addProductToShipment(p2, 3);
        one.addProductToShipment(p3, 12);
        one.addProductToShipment(p4, 2);
        one.addProductToShipment(p5, 5);

// Add products to Shipment Two
        Product p6 = new Product("Lettuce", 1, 1);
        Product p7 = new Product("Tomatoes", 1, 2);
        Product p8 = new Product("Milk", 2, 3);
        Product p9 = new Product("Butter", 1, 1);
        Product p10 = new Product("Bread", 1, 2);
        two.addProductToShipment(p6, 15);
        two.addProductToShipment(p7, 10);
        two.addProductToShipment(p8, 6);
        two.addProductToShipment(p9, 8);
        two.addProductToShipment(p10, 12);

// Add products to Shipment Three
        Product p11 = new Product("Potatoes", 2, 4);
        Product p12 = new Product("Rice", 3, 2);
        Product p13 = new Product("Beans", 1, 1);
        Product p14 = new Product("Eggs", 1, 3);
        Product p15 = new Product("Yogurt", 1, 2);
        three.addProductToShipment(p11, 100);
        three.addProductToShipment(p12, 5);
        three.addProductToShipment(p13, 10);
        three.addProductToShipment(p14, 6);
        three.addProductToShipment(p15, 10);

// Add products to Shipment Four
        Product p16 = new Product("Oranges", 1, 2);
        Product p17 = new Product("Chicken", 4, 8);
        Product p18 = new Product("Onions", 1, 1);
        Product p19 = new Product("Cucumbers", 1, 2);
        Product p20 = new Product("Juice", 3, 5);
        four.addProductToShipment(p16, 10);
        four.addProductToShipment(p17, 4);
        four.addProductToShipment(p18, 8);
        four.addProductToShipment(p19, 10);
        four.addProductToShipment(p20, 6);

        this.bookingSystem.addNewShipment(one);
        this.bookingSystem.addNewShipment(two);
        this.bookingSystem.addNewShipment(three);
        this.bookingSystem.addNewShipment(four);
    }
}
