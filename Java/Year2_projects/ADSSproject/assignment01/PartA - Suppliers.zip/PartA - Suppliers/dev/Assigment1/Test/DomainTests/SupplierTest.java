package DomainTests;

import DomainInventory.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class SupplierTest {

    @Test
    void testSupplierCreation() {
        // Test creating a supplier and checking initial fields
        Supplier supplier = new Supplier("Supplier1", "123456789");
        assertEquals("Supplier1", supplier.getSupplierName());
        assertEquals("123456789", supplier.getBankAccountNumber());
        assertTrue(supplier.isActive());
    }

    @Test
    void testAddAndGetContact() {
        // Test adding a contact and retrieving it
        Supplier supplier = new Supplier("Supplier2", "987654321");
        supplier.addContact("John Doe", "0501111111");

        assertEquals(1, supplier.getContactDetails().size());
        assertEquals("John Doe", supplier.getContactDetails().get(0).getName());
    }

    @Test
    void testAddAndGetProduct() {
        // Test adding a product to supplier and retrieving it
        Supplier supplier = new Supplier("Supplier3", "111222333");
        Product product = new Product(1000, 50.0, supplier.getSupplierID(), "Tomato", "FactoryA", "Food");

        assertTrue(supplier.addProductToMap(product));
        assertEquals(product, supplier.getProduct(product.getCatalogID()));
    }

    @Test
    void testRemoveProductFromMap() {
        // Test removing a product from supplier
        Supplier supplier = new Supplier("Supplier4", "333222111");
        Product product = new Product(1001, 30.0, supplier.getSupplierID(), "Juice", "FactoryB", "Drink");

        supplier.addProductToMap(product);
        Product removed = supplier.removeProductFromMap(product.getCatalogID());

        assertEquals(product, removed);
        assertNull(supplier.getProduct(product.getCatalogID()));
    }

    @Test
    void testAddAndGetManufacturer() {
        // Test adding a manufacturer and retrieving it
        Supplier supplier = new Supplier("Supplier5", "222333444");
        supplier.addManufacturer("FactoryA");

        ArrayList<String> manufacturers = supplier.getManufacturers();
        assertTrue(manufacturers.contains("FactoryA"));
    }

    @Test
    void testAddAndGetProductType() {
        // Test adding a product type and retrieving it
        Supplier supplier = new Supplier("Supplier6", "555666777");
        supplier.addProductType("Drink");

        ArrayList<String> types = supplier.getProductTypes();
        assertTrue(types.contains("Drink"));
    }

    @Test
    void testSetBankAccountNumber() {
        // Test changing the bank account number
        Supplier supplier = new Supplier("Supplier7", "000000000");
        supplier.setBankAccountNumber("999888777");

        assertEquals("999888777", supplier.getBankAccountNumber());
    }

    @Test
    void testSetActiveAndUnActive() {
        // Test activating and deactivating a supplier
        Supplier supplier = new Supplier("Supplier8", "222444666");
        supplier.setUnActive();
        assertFalse(supplier.isActive());

        supplier.setActive();
        assertTrue(supplier.isActive());
    }

    @Test
    void testAddAgreementAndFindAgreement() {
        // Test adding an agreement and finding it by ID
        Supplier supplier = new Supplier("Supplier9", "333555777");
        Agreement agreement = new PickUpAgreement(supplier.getSupplierID(),"Cash", "Main Address");

        supplier.addAgreement(agreement);
        Agreement found = supplier.findAgreement(agreement.getAgreementID());

        assertNotNull(found);
        assertEquals(agreement.getAgreementID(), found.getAgreementID());
    }

    @Test
    void testHasProductWithID() {
        // Test checking if a product exists by its ID
        Supplier supplier = new Supplier("Supplier10", "666999333");
        Product product = new Product(1002, 20.0, supplier.getSupplierID(), "Beer", "FactoryC", "Drink");

        supplier.addProductToMap(product);

        assertTrue(supplier.hasProductWithID(product.getProductID()));
        assertFalse(supplier.hasProductWithID(9999));
    }
}
