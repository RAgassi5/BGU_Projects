package Service;

import Data.ItemInstance;
import Domain.ADiscount;
import Data.Category;
import Data.Status;
import Domain.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Inventory {
    //Fields:
    private final List<ADiscount> discountsInStore;
    private final Map<Integer, ItemTemplate> itemsInStore;
    private DateOrganizer dateManager;
    private CategoryOrganizer catsManager;

    //Constructor:
    public Inventory() {
        this.discountsInStore = new ArrayList<ADiscount>();
        this.itemsInStore = new HashMap<Integer, ItemTemplate>();
        this.dateManager = new DateOrganizer(); //sets Service.Inventory current date to runtime date
        this.catsManager = new CategoryOrganizer();
    }

    //Methods:
    public Status addItem(String itName, String prodName, double sPrice, int minAmount, String primCat, String secCat,
                          String sizeCat) {
        //creating fields for Domain layer
        Category primary = this.catsManager.setCategory(primCat, 1);
        Category secondary = this.catsManager.setCategory(secCat, 2);
        Category size = this.catsManager.setCategory(sizeCat, 3);
        if (primary.getRank() != 1 || secondary.getRank() != 2 || size.getRank() != 3)
            return Status.Failure; //tried to add different rank category as primary.
        //other fields have validation in Presentation layer.
        //create item
        ItemTemplate toAdd = new ItemTemplate(itName, prodName, sPrice, minAmount, primary, secondary, size);
        //add to inventory
        this.itemsInStore.put(toAdd.getItemplateID(), toAdd);
        System.out.println("Product has been added successfully, new ProductID: " + toAdd.getItemplateID());
        return Status.Success;
    }

    //Tables printers:
    public void getItemplateIDTable() {
        if (this.itemsInStore.isEmpty()) {
            System.out.println("No products found in the system.");
            return;
        }

        System.out.println("Product ID Table:");
        System.out.println("-----------------");

        int i = 1;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            int itemplateID = entry.getValue().getItemplateID();
            String itemName = entry.getValue().getItemName();
            System.out.println(i + ": Product: " + itemName + " | ID: " + itemplateID);
            i++;
        }
    }

    public Status getItemIDTable(int itemplateID) {
        ItemTemplate toGet = this.itemsInStore.get(itemplateID);
        if (toGet == null)
            return Status.Failure; //item does not exist
        int[] items = toGet.getAllItemIDs();
        if (toGet.getTotalAmount() == 0) { //no units, give proper output.
            System.out.println("No units found for Product ID: " + itemplateID);
            return Status.Success;
        } //units found, print them
        System.out.println("Unit ID Table:");
        System.out.println("--------------");
        int i = 1;
        for (int id : items) {
            System.out.println(i + ": Unit ID: " + id);
            i++;
        }
        return Status.Success;
    }

    public void getCategoryTable(int rank) {
        //get all category names by given rank (1=primary, 2=secondary, 3=size)
        List<String> toPrint = this.catsManager.getCategoriesByRank(rank);

        //no categories of that rank (can happen only if no items yet)
        if (toPrint.isEmpty()) {
            System.out.println("No categories found for selected rank.");
            return;
        }

        //print all category names with running index
        int i = 1;
        for (String catName : toPrint) {
            System.out.println(i + ": Category name: " + catName);
            i++;
        }
    }

    public Status setDate(int dd, int mm, int yy) {
        Status status = this.dateManager.setDate(dd, mm, yy);
        if (status == Status.Success) {
            System.out.println("System date updated to: " + dd + "/" + mm + "/" + yy);
        }
        return status;
    }

    public void printCurrentDate() {
    LocalDate current = this.dateManager.getDate();
    System.out.println("Current system date: " + current.getDayOfMonth() + "/" + current.getMonthValue() + "/" + current.getYear());
    }

    //Getters by itemplateID:
    //Getters does not valid itemplateID if not exist because validation happens with isExist in main
    public void getStorageAmount(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        int storageAmount = getFrom.getStorageAmount();
        System.out.println("Storage quantity: " + storageAmount);
    }

    public void getShelfAmount(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        int shelvesAmount = getFrom.getShelfAmount();
        System.out.println("Shelves quantity: " + shelvesAmount);
    }

    public void getTotalAmount(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        int totalAmount = getFrom.getTotalAmount();
        System.out.println("Total quantity: " + totalAmount);
    }

    public void getMinAmount(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        int minAmount = getFrom.getMinAmount();
        System.out.println("Minimum quantity: " + minAmount);
    }

    public void getSellPrice(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        LocalDate current = this.dateManager.getDate();
        SPbyD(getFrom, current);
    }

    public Status getCostPrice(int itemplateID) {
        ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
        return CPbyD(getFrom, this.dateManager.getDate());
    }

    public Status getSPriceByD(int itemplateID, int dd, int mm, int yy) {
        try {
            ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
            LocalDate givenDate = LocalDate.of(yy, mm, dd);
            SPbyD(getFrom, givenDate);
            return Status.Success;
        } catch (Exception e) {
            return Status.Failure;
        }
    }


    public Status getCPriceByD(int itemplateID, int dd, int mm, int yy) {
        try {
            ItemTemplate getFrom = this.itemsInStore.get(itemplateID);
            LocalDate givenDate = LocalDate.of(yy, mm, dd);
            return CPbyD(getFrom, givenDate);
        } catch (Exception e) {
            return Status.Failure;
        }
    }


    //Setters by itemplateID, all verifications in main.

    public void setMinAmount(int itemplateID, int minAmount) {//validation in presentation layer.
        ItemTemplate setInto = this.itemsInStore.get(itemplateID);
        setInto.setMinAmount(minAmount);
        System.out.println("Minimum quantity as been set for Product: " + setInto.getItemName() + "ID: " + setInto.getItemplateID());
    }

    public void setSPrice(int itemplateID, double sp) {
        ItemTemplate setInto = this.itemsInStore.get(itemplateID);
        setInto.setSalePrice(sp);
        System.out.println("Sale price as been set for Product: " + setInto.getItemName() + "ID: " + setInto.getItemplateID());

    }

    public Status addUnitsFromDelivery(int itemplateID, int amount, int ddA, int mmA, int yyA,
                                       int ddEx, int mmEX, int yyEx, String location, double cost) {
        try {
            ItemTemplate addInto = this.itemsInStore.get(itemplateID);
            LocalDate arriveDate = LocalDate.of(yyA, mmA, ddA);
            LocalDate expiryDate = LocalDate.of(yyEx, mmEX, ddEx);
            int[] res = addInto.addItems(amount, expiryDate, arriveDate, location, cost);

            System.out.println(amount + " units have been added to product: " +
                               addInto.getItemName() + " ID: " + addInto.getItemplateID());
            System.out.println("New unit IDs:");
            for (int id : res)
                System.out.println(id);

            return Status.Success;
        } catch (Exception e) {
            return Status.Failure;
        }
    }


    //Unit actions:
    public Status storageToShelf(int itemID) {
        Status st = Status.Failure;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            st = toCheck.storageToShelf(itemID);
            if (st == Status.Success) {
                break;
            }
        }
        return st;
    }

    public Status removeFromStore(int itemID) {
        Status st = Status.Failure;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            st = toCheck.removeItem(itemID);
            if (st == Status.Success) {
                break;
            }
        }
        return st;
    }

    public Status setDefective(int itemID) {
        Status st = Status.Failure;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            st = toCheck.setDefectiveItem(itemID);
            if (st == Status.Success) {
                break;
            }
        }
        return st;
    }


    //Discount actions:
    public Status setDiscountByTID(int itemplateID, double rate, int ddS, int mmS, int yyS,
                                   int ddE, int mmE, int yyE) {
        try {
            ItemTemplate toAdd = this.itemsInStore.get(itemplateID);
            if (toAdd == null)
                return Status.Failure;
            LocalDate sDate = LocalDate.of(yyS, mmS, ddS);
            LocalDate eDate = LocalDate.of(yyE, mmE, ddE);
            ADiscount newDiscount = new ItemDiscount(rate, sDate, eDate, itemplateID);
            this.discountsInStore.add(newDiscount);
            return Status.Success;
        } catch (Exception e) {
            return Status.Failure;
        }
    }


    public Status setDiscountByCat(String catName, double rate, int ddS, int mmS, int yyS,
                                   int ddE, int mmE, int yyE) {
        try {
            Category toAdd = this.catsManager.isExist(catName);
            if (toAdd == null)
                return Status.Failure;
            LocalDate sDate = LocalDate.of(yyS, mmS, ddS);
            LocalDate eDate = LocalDate.of(yyE, mmE, ddE);
            ADiscount newDiscount = new CategoryDiscount(rate, sDate, eDate, catName);
            this.discountsInStore.add(newDiscount);
            return Status.Success;
        } catch (Exception e) {
            return Status.Failure;
        }
    }



    //Reports:
    public Status getStockByCategory(String cName) {
        Category getFrom = this.catsManager.isExist(cName);
        if (getFrom == null)
            return Status.Failure;
        int i = 1;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            if (toCheck.belongsToCat(cName)) {
                int distance = toCheck.getTotalAmount() - toCheck.getMinAmount();
                String status = (distance < 0) ? "below" : "above";
                if (distance < 0)
                    distance = -distance;
                System.out.println(i + ": Product " + toCheck.getItemName() + " ID: " + toCheck.getItemplateID() + " is " +
                                   distance + " units " + status + " the minimum required.");
                i++;
            }
        }
        if (i == 1) {
            System.out.println("No products found in category");
        }
        return Status.Success;
    }

    public void getExpireds() {
        int i = 1;
        boolean foundEx = false;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            List<Integer> instances = toCheck.getAllExpired(this.dateManager.getDate());
            if (instances.isEmpty())
                continue;
            for (int expiredID : instances) {
                System.out.println(i + ": " + "Unit: " +  expiredID + " of product " + toCheck.getItemplateID());
                foundEx = true;
                i++;
            }
        }
        if (!foundEx)
            System.out.println("No expired units in store");
    }

    public void getShortages() {
        int i = 1;
        boolean found = false;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            int difference = toCheck.getTotalAmount() - toCheck.getMinAmount();
            if (difference < 0) {
            System.out.println(i + ": Product " + toCheck.getItemName() + " ID " + toCheck.getItemplateID() +
                               " is missing " + (-difference) + " units.");
                found = true;
                i++;
            }
        }
        if (!found)
            System.out.println("No shortages in store");
    }

    public void getDefectives() {
        int i = 1;
        boolean foundEx = false;
        for (Map.Entry<Integer, ItemTemplate> entry : this.itemsInStore.entrySet()) {
            ItemTemplate toCheck = entry.getValue();
            List<Integer> instances = toCheck.getAllDefectives();
            if (instances.isEmpty())
                continue;
            for (int expiredID : instances) {
                System.out.println(i + ": " + "Unit: " +  expiredID + " of product " + toCheck.getItemplateID());
                foundEx = true;
                i++;
            }
        }
        if (!foundEx)
            System.out.println("No defective units in store");
    }


    //Helper methods:
    private void SPbyD(ItemTemplate item, LocalDate date) { //helper method, arguments given after validation
        double salePrice = item.getSalePrice();
        for (ADiscount discount : this.discountsInStore) {
            LocalDate startD = discount.getStartDate();
            LocalDate endD = discount.getEndDate();
            if (!this.dateManager.inRange(startD, endD, date)) //if in date range
                continue;
            if (!discount.hasDiscount(item)) //if relevant
                continue;
            salePrice = salePrice - salePrice*discount.getDiscountRate()/100; //adjust the price
        }
        System.out.println("Sell price: " + salePrice);
    }

    private Status CPbyD(ItemTemplate getFrom, LocalDate date) {
        double cp = getFrom.getCostPrice(date); //given date cp
        if (cp == -1 || cp == -2) //no orders yet
            return Status.Failure;
        System.out.println("Cost price: " + cp);
        return Status.Success;
    }

    public Status isExist(int itemplateID) {
        ItemTemplate isEx = this.itemsInStore.get(itemplateID);
        if (isEx == null)
            return Status.Failure;
        return Status.Success;
    }
}
