package Data;

import java.time.LocalDate;

public class ItemInstance {
    //Fields:
    private static int iIDCounter = 1;
    private final int itemID;
    private String itemLocation;
    private final LocalDate expiryDate;
    private boolean isDefective;

    //Constructor:
    public ItemInstance(String location, LocalDate expDate) {
        this.itemLocation = location;
        this.expiryDate = expDate;
        this.isDefective = false;
        this.itemID = iIDCounter;
        iIDCounter++;
    }

    //Methods:
    public String getLocation() {
        return itemLocation; //immutable, no need to worry
    }

    public boolean isDefective () {return this.isDefective;}

    public Status setDefective() { //assign to defective and no way to return it to normal.
        this.isDefective = true;
        return Status.Success;
    }

    public Status setLocation(String location) {
        if (location.equals("Storage") || location.equals("Shelfs")) {
            this.itemLocation = location;
            return Status.Success;
        }
        return Status.Failure;
    }

    public LocalDate getExpiryDate() {
        return this.expiryDate; //immutable as well.
    }

    public int getItemID() {
        return itemID;
    }
}
