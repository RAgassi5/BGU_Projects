package Domain;

import Data.Status;

import java.time.DateTimeException;
import java.time.LocalDate;

public class DateOrganizer {
    //Fields
    private LocalDate currentDate;

    //Constructor
    public DateOrganizer(){
        this.currentDate = LocalDate.now();
    }

    //Functions
    public LocalDate getDate(){return currentDate;}

    //need to set date manually
    public Status setDate(int day, int month, int year) {
        if (day > 31 || day < 1 || month > 12 || month < 1)
            return Status.Failure;
        try {
            this.currentDate = LocalDate.of(year, month, day);
        } catch (DateTimeException e) {
            return Status.Failure;
        }
        return Status.Success;
    }
    
    //given 3 dates, check if checkDate is in range (include edges).
    public boolean inRange(LocalDate startDate, LocalDate endDate, LocalDate checkDate ){
        return (checkDate.isEqual(startDate) || (checkDate.isAfter(startDate) &&
                checkDate.isBefore(endDate)) || checkDate.isEqual(endDate));
    }
}
