package DomainInventory;

public class FlexibleDeliveryAgreement extends DeliverableAgreement{
    private int supplyDays;

    // Constructor - Initializes a FlexibleDeliveryAgreement and correctly saves supplyDays.
    public FlexibleDeliveryAgreement(int supplierID, String paymentMethod,int supplyDays) {
        super(supplierID, paymentMethod);
        this.supplyDays = supplyDays;
    }

    // Overrides the agreement type to "Flexible Delivery".
    @Override
    public String getAgreementType(){
        return "Flexible Delivery";
    }

}
