package Domain;

public class Van extends Vehicle{
    public Van(int licenseNum){
        super(licenseNum,50, 100);
    }

    @Override
    public String getVehicleType(){
        return "Van";
    }
}
