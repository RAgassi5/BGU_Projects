package PresentationInventory;

import DomainInventory.Agreement;
import DomainInventory.Product;
import ServiceInventory.SupplierService;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Scanner;

public class SupplierUI {
    static Scanner scanner = new Scanner(System.in);
    private final SupplierService supplierService;

    public SupplierUI(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    // Main menu for managing suppliers
    public void manageSupplier() {
        boolean run = true;
        while (run) {
            System.out.println("Welcome to the suppliers manager:");
            System.out.println("1. Add a new supplier");
            System.out.println("2. Edit supplier details");
            System.out.println("3. Check/change supplier status");
            System.out.println("4. Display supplier details");
            System.out.println("5. Display suppliers by product");
            System.out.println("6. Display supplier product types");
            System.out.println("7. Display supplier manufacturers");
            System.out.println("8. Add a new product");
            System.out.println("9. Delete a product");
            System.out.println("10. Change bank account number");
            System.out.println("11. Show active suppliers");
            System.out.println("12. Back to main menu");

            int choice = ViewManger.promptMenuChoice(12);
            switch (choice) {
                case 1 -> addNewSupplier();
                case 2 -> editSupplierDetails();
                case 3 -> checkOrChangeSupplierStatus();
                case 4 -> displaySupplierDetails();
                case 5 -> displaySuppliersByProduct();
                case 6 -> displaySupplierTypes();
                case 7 -> displaySupplierManufacturers();
                case 8 -> addProductFlow();
                case 9 -> deleteProductFlow();
                case 10 -> changeBankAccount();
                case 11 -> showActiveSuppliers();
                case 12 -> run = false;
            }
        }
    }

    // Adds a new supplier after taking name and bank account number
    private void addNewSupplier() {
        System.out.println("Enter supplier name:");
        String supplierName = scanner.nextLine();
        System.out.println("Enter bank account number:");
        String bankAccountNumber = scanner.nextLine();
        int supplierId = supplierService.createSupplier(supplierName, bankAccountNumber);
        System.out.println("Supplier " + supplierId + " added successfully.");
    }

    // Edits supplier details if the supplier exists
    private void editSupplierDetails() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        supplierEdit(supplierID);
    }

    // Checks the status of the supplier (active/inactive) and allows changing it
    private void checkOrChangeSupplierStatus() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        if (supplierService.checkSupplierStatus(supplierID)) {
            System.out.println("Supplier is ACTIVE.");
        } else {
            System.out.println("Supplier is INACTIVE.");
        }
        System.out.print("Would you like to change the supplier status? (yes/no): ");
        if (scanner.nextLine().trim().equalsIgnoreCase("yes")) {
            if (supplierService.changeStatusService(supplierID)) {
                System.out.println("Supplier deactivated.");
            } else {
                System.out.println("Supplier activated.");
            }
        }
    }

    // Displays full details of a supplier
    private void displaySupplierDetails() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        System.out.println(supplierService.getSupplier(supplierID));
    }

    // Displays a list of suppliers that supply a specific product
    private void displaySuppliersByProduct() {
        int productID = ViewManger.promptForInt("Enter product ID:");
        ArrayList<Integer> suppliers = supplierService.getProductSuppliers(productID);
        if (suppliers.isEmpty()) {
            System.out.println("No suppliers found for product ID: " + productID);
        } else {
            System.out.println("Suppliers that supply product ID " + productID + ":");
            for (int sid : suppliers) {
                System.out.println("- Supplier ID: " + sid);
            }
        }
    }

    // Displays all product types for a supplier
    private void displaySupplierTypes() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        System.out.println("Product types: " + supplierService.getAllTypes(supplierID));
    }

    // Displays all manufacturers related to a supplier
    private void displaySupplierManufacturers() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        System.out.println("Manufacturers: " + supplierService.getAllManufacturers(supplierID));
    }

    // Flow for adding a new product to a supplier
    private void addProductFlow() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        addNewProduct(supplierID, -1);
    }

    // Flow for deleting a product from a supplier
    private void deleteProductFlow() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        int catalogID = ViewManger.promptForInt("Enter catalog ID:");
        if (!supplierService.checkIfProductExist(supplierID, catalogID)) {
            System.out.println("Product does not exist.");
            return;
        }
        supplierService.deleteProductFromSystem(catalogID, -1, supplierID);
        System.out.println("Product deleted successfully.");
    }

    // Changes the supplier's bank account number
    private void changeBankAccount() {
        int supplierID = ViewManger.promptForInt("Enter supplier ID:");
        if (!supplierService.doesSupplierExist(supplierID)) {
            System.out.println("Supplier does not exist.");
            return;
        }
        System.out.println("Enter new bank account number:");
        String bankAccountNumber = scanner.nextLine();
        supplierService.changeBankAccountNumber(bankAccountNumber, supplierID);
        System.out.println("Bank account updated.");
    }

    // Shows a list of active suppliers
    private void showActiveSuppliers() {
        ArrayList<Integer> activeSuppliers = supplierService.getActiveSuppliers();
        if (activeSuppliers.isEmpty()) {
            System.out.println("No active suppliers found.");
        } else {
            System.out.println("Active Suppliers:");
            for (int id : activeSuppliers) {
                System.out.println("- Supplier ID: " + id);
            }
        }
    }

    // Menu for editing a supplier's specific options (contacts, agreements, etc.)
    private void supplierEdit(int supplierID) {
        boolean run = true;
        while (run) {
            System.out.println("Edit supplier:");
            System.out.println("1. Add new contact");
            System.out.println("2. Edit agreement");
            System.out.println("3. Create new agreement");
            System.out.println("4. Exit");

            int choice = ViewManger.promptMenuChoice(4);
            switch (choice) {
                case 1 -> addContactToSupplier(supplierID);
                case 2 -> editAgreementFlow(supplierID);
                case 3 -> createNewAgreement(supplierID);
                case 4 -> run = false;
            }
        }
    }

    // Adds a new contact to a supplier
    private void addContactToSupplier(int supplierID) {
        System.out.println("Enter contact name:");
        String name = scanner.nextLine();
        System.out.println("Enter contact phone:");
        String phone = scanner.nextLine();
        supplierService.addContactToSupplier(supplierID, name, phone);
        System.out.println("Contact added successfully.");
    }

    // Creates a new agreement (PickUp, FixedDelivery, or FlexibleDelivery) for a supplier
    private void createNewAgreement(int supplierID) {
        System.out.println("Choose agreement type:");
        System.out.println("1. PickUp");
        System.out.println("2. FixedDelivery");
        System.out.println("3. FlexibleDelivery");

        int choice = ViewManger.promptMenuChoice(3);
        System.out.println("Enter payment method:");
        String paymentMethod = scanner.nextLine();

        int agreementID = -1;
        switch (choice) {
            case 1 -> {
                System.out.println("Enter pickup address:");
                String address = scanner.nextLine();
                if(!supplierService.checkValidAgreement("PickUp", supplierID))
                {
                    System.out.println("PickUp agreement already exists.");
                }
                agreementID = supplierService.CreatePickUpAgreement(paymentMethod, supplierID, address);
            }
            case 2 -> agreementID = supplierService.CreateFixedAgreement(paymentMethod, supplierID, chooseSupplyDays());


            case 3 -> {
                if(!supplierService.checkValidAgreement("Flexible Delivery", supplierID))
                {
                    System.out.println("Flexible Delivery agreement already exists.");
                }
                System.out.println("Enter supply days:");
                int supplyDays = ViewManger.promptForInt("Days:");
                agreementID = supplierService.CreateFlexibleAgreement(paymentMethod, supplierID, supplyDays);
            }
        }
        if (agreementID != -1) {
            addNewProduct(supplierID, agreementID);
        }
    }

    // Lets the user choose supply days for FixedDelivery agreement
    private ArrayList<DayOfWeek> chooseSupplyDays() {
        System.out.println("Choose days (1=Sunday to 7=Saturday, separated by commas):");
        String[] input = scanner.nextLine().split(",");
        ArrayList<DayOfWeek> days = new ArrayList<>();
        for (String day : input) {
            int dayNum = Integer.parseInt(day.trim());
            days.add(DayOfWeek.of(dayNum));
        }
        return days;
    }

    // Flow for editing an existing agreement
    private void editAgreementFlow(int supplierID) {
        ArrayList<Agreement> agreements = supplierService.getAllAgreementsBySupplier(supplierID);
        if (agreements.isEmpty()) {
            System.out.println("No agreements for supplier.");
            return;
        }
        for (Agreement agreement : agreements) {
            System.out.println(agreement);
        }
    }

    // Adds a new product and connects it to an agreement (if needed)
    private void addNewProduct(int supplierID, int agreementID) {
        System.out.println("Adding new product:");
        int catalogID = ViewManger.promptForInt("Enter catalog ID:");
        System.out.println("Enter product name:");
        String name = scanner.nextLine();
        System.out.println("Enter product price:");
        double price = ViewManger.promptForInt("Price:");
        System.out.println("Enter manufacturer:");
        String manufacturer = scanner.nextLine();
        System.out.println("Enter product type:");
        String type = scanner.nextLine();
        supplierService.addNewProductToAgreement(catalogID, price, supplierID, name, agreementID, manufacturer, type);
        System.out.println("Product added.");
    }
}
