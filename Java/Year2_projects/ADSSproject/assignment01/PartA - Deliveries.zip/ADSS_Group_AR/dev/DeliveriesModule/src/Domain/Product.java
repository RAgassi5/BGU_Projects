package Domain;

public class Product {
    private String name;
    private int amount;
    private int weightPerUnit;

    public Product(String name, int amount, int weightPerUnit) {
        this.name = name;
        this.amount = 1;
        this.weightPerUnit = weightPerUnit;
    }

    public int calculateFullWeight(){
        return this.amount * this.weightPerUnit;
    }

    public Product takePortionFromProduct(int weight){
        int amountToRemove = weight / this.weightPerUnit;
        Product portion = new Product(this.name, amountToRemove, weightPerUnit);
        this.amount -= amountToRemove;
        return portion;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void printProduct(){
        System.out.println("Product Name:" + this.name);
        System.out.println("    --> Total weight: " + this.calculateFullWeight() + " kg");
    }

}
