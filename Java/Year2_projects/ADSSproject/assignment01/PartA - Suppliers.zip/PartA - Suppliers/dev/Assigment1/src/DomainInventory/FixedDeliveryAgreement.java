package DomainInventory;

import java.util.ArrayList;
import java.time.DayOfWeek;

public class FixedDeliveryAgreement extends DeliverableAgreement {
    private ArrayList<DayOfWeek> supplyDays;

    // Constructor - Initializes a FixedDeliveryAgreement but missing setting supplyDays field.
    public FixedDeliveryAgreement(int supplierID, String paymentMethod,ArrayList<DayOfWeek> supplyDays) {
        super(supplierID, paymentMethod);
        this.supplyDays = supplyDays;
    }

    // Overrides the agreement type to "FixedDelivery".
    @Override
    public String getAgreementType(){
        return "FixedDelivery";
    }

}
