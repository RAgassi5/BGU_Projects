package Presentation;

import Domain.Route;
import Domain.s_status;
import Service.RouteManager;

import java.time.format.DateTimeFormatter;

public class RouteController {
    private final RouteManager routeManager;

    public RouteController() {
        this.routeManager = RouteManager.getInstance();
    }

    public void startRouting() {
        this.routeManager.startAutoRunning();
    }

    public void stopProgram() {
        this.routeManager.stopRouting();
    }

    public void sendOutShipments() {
        Route currentRoute = this.routeManager.sendOutAwaitingShipments();
        if (currentRoute == null) {
            System.out.println("No awaiting shipments at the moment");
        } else if (currentRoute.getStatus() == s_status.DELAYED) {
            System.out.println("The shipment is waiting for a driver");

        } else if (currentRoute.getStatus() == s_status.OVERWEIGHT) {
            System.out.println("The shipment is overweight, please go edit the shipment");

        } else {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
            System.out.println("The shipment of " + currentRoute.getRouteDate().format(dateFormatter) + " to district " + currentRoute.getCurrentDistrict() + " was sent out to shipment at " + currentRoute.getDepartureTimeForAllShipments().format(timeFormatter) +" !");
        }
    }
    public void printProductsInShipment(){
        this.routeManager.printAllProductsInOverWeightRoute();
    }
    public boolean checkOverWeight() {
       return this.routeManager.checkOverWeight();
    }
}
