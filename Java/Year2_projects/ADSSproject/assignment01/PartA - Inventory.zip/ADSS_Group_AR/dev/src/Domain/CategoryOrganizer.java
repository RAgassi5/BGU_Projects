package Domain;

import Data.Category;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoryOrganizer {
    private final HashMap<String, Category> allCat;
    private int size;

    public CategoryOrganizer() {
        this.allCat = new HashMap<String, Category>(); //initialize CategoryMap
        this.size = 0; //initialize empty size
    }

    public Category setCategory(String name_category, int rank) {
        if (!allCat.containsKey(name_category)) { //if not exist yet
            Category newCategory = new Category(name_category, rank); //create
            allCat.put(name_category, newCategory);
            this.size++; //update size
        }
        return allCat.get(name_category); //return the new created / already exist category to set in Item.
    }

    public List<String> getCategoriesByRank(int rank) {
        ArrayList<String> res = new ArrayList<>();
        for (Map.Entry<String, Category> entry : this.allCat.entrySet()) {
            Category toCheck = entry.getValue();
            if (toCheck.getRank() == rank)
                res.add(toCheck.getName());
        }
        return res;
    }

    //returns null if not Exist
    public Category isExist (String name) {
        return this.allCat.get(name);
    }
}
