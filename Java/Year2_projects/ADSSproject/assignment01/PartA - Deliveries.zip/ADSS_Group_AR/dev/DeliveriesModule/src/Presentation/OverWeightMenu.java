package Presentation;

import java.util.Scanner;

public class OverWeightMenu {


    public void run(Scanner scanner, RouteController routeController) {
        int choice;

        do {
            choice = displayOverWeightMenu(scanner);
            switch (choice) {
                case 1:
                    routeController.printProductsInShipment();
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 0:
                    break;
            }
        } while (choice != 0);

    }

    public static int displayOverWeightMenu(Scanner scanner) {
        int buffer;
        while (true) {
            try {
                System.out.println("\n=== OverWeight Menu ===");
                System.out.println("Welcome to the OverWeight Menu!");
                System.out.println("1. Print current overweight shipment");
                System.out.println("2. Edit products in route");
                System.out.println("3. Remove a shipment from route");
                System.out.println("4. Send route to rescheduling");
                System.out.println("0. Return to main menu");
                buffer = scanner.nextInt();
                if (buffer >= 0 && buffer <= 4) {
                    break;
                } else {
                    System.out.println("Invalid input, please select from the given options");
                }
            } catch (Exception e) {
                System.out.println("Invalid input, please select from the given options");
                scanner.nextLine();
            }
        }
        return buffer;
    }
}
