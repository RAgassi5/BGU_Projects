package Service;

import Domain.Driver;
import Domain.driver_status;

import java.util.Hashtable;

public class DriversManager {
    private Hashtable<String, Driver> currentlyWorkingDrivers;
    private static DriversManager currentDriversManager;

    private DriversManager() {
        currentlyWorkingDrivers = new Hashtable<>();
    }

    /**
     * a function that returns the instance of the driversManager
     * makes sure it stays a Singleton
     *
     * @return current instance of DriversManager
     */
    public static DriversManager getInstance() {
        if (currentDriversManager == null) {
            currentDriversManager = new DriversManager();
        }
        return currentDriversManager;

    }

    /**
     * a function that adds a driver to the available drivers
     *
     * @param driverName the name of the new driver
     */
    public void addDriver(String driverName) {
        currentlyWorkingDrivers.put(driverName, new Driver(driverName));
        System.out.println("Driver " + driverName + " has been added to the system successfully !");

    }

    /**
     * a function that removes a driver from the available drivers
     *
     * @param driverName the name of the driver to be removed
     */
    public void deleteDriver(String driverName) {
        if(currentlyWorkingDrivers.remove(driverName) == null){
            System.out.println("There is no driver named: " + driverName + " in the system!");
        }else{
            System.out.println(driverName + " was deleted successfully from the system!");
        }
    }

    /**
     * @param driverName the driver's name to be updated
     * @param status     the status to set
     */
    public void setDriverStatus(String driverName, driver_status status) {
        Driver currentDriver = currentlyWorkingDrivers.get(driverName);
        if (currentDriver != null) {
            currentDriver.setDriverStatus(status);
        }
    }

    /**
     * a function that adds a license type to a specific driver
     *
     * @param driverName the name of the driver
     * @param license    the type of license
     */
    public void setDriverLicense(String driverName, String license) {
        Driver currentDriver = currentlyWorkingDrivers.get(driverName);
        if(!license.equals("Truck") && !license.equals("Van")){
            System.out.println("Invalid license type! ");
            System.out.println("Choose from valid options: 1) Truck  2) Van");
            return;
        }

        if (currentDriver == null) {
            System.out.println("There is no driver named " + driverName + " in the system!");

        }
        else{
            currentDriver.addLicense(license);
            System.out.println(driverName + "'s licenses have been updated!");
        }
    }

    /**
     * a function that retrieves a driver according to the license type
     *
     * @param license the license type to search for
     * @return an instance of driver that has the wanted license type
     */
    public Driver assignDriver(String license) {
        for (Driver driver : currentlyWorkingDrivers.values()) {
            if (driver.getLicense(license) && driver.getDriverStatus() == driver_status.FREE) {
                driver.setDriverStatus(driver_status.WORKING);
                return driver;
            }
        }
        return null;
    }
public void printAvailableDrivers() {
        for (Driver driver : currentlyWorkingDrivers.values()) {
            driver.printDriver();
        }
}
public int getDriverCount() {
        return currentlyWorkingDrivers.size();
}

}
