package Presentation;

import java.util.Scanner;

public class MainMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        new InitializationMenu().run(scanner);
        RouteController controller = new RouteController();
        BookingController bookingController = new BookingController();
        controller.startRouting();
        int choice;
        do {
            choice = displayMenu(scanner);
            switch (choice) {
                case 1:
                    new BookingMenu().run(scanner);
                    break;

                case 2:
                    controller.sendOutShipments();
                    break;

                case 3:
                    System.out.println("\n=== Track Your Shipment ===");
                    System.out.println("Enter your shipment ID:");
                    int ID = scanner.nextInt();
                    scanner.nextLine();
                    bookingController.trackShipment(ID);
                    break;

                case 4:
                    if(controller.checkOverWeight()){
                        System.out.println("\nThere are no overweight shipments at the moment!");
                    }else {
                        new OverWeightMenu().run(scanner, controller);
                    }
                    break;

                case 5:
                    new ManagementMenu().run(scanner);
                    break;

                case 0:
                    controller.stopProgram();
                    System.out.println("Thank you for choosing SUPER-LEE!");
                    System.out.println("We hope to see you again soon :) ");
                    System.out.println("Exiting menu...");
                    break;

                default:
                    System.out.println("Invalid input, please select from the given options");
                    break;
            }

        } while (choice != 0);
        scanner.close();
    }

    /**
     * a function that displays the main menu
     *
     * @param scanner a scanner to receive the user's input
     * @return the user's choice
     */
    public static int displayMenu(Scanner scanner) {
        int buffer;

        while (true) {
            try {
                System.out.println("\n=== Deliveries Menu ===");
                System.out.println("1. Book a new shipment");
                System.out.println("2. Send out awaiting shipment");
                System.out.println("3. Track a shipment");
                System.out.println("4. Edit an overweight shipment");
                System.out.println("5. Management menu");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                buffer = scanner.nextInt();
                if (buffer >= 0 && buffer <= 5) {
                    break;
                } else {
                    System.out.println("Invalid input, please select from the given options");
                }

            } catch (Exception e) {
                System.out.println("Invalid input, please select from the given options");
                scanner.nextLine();
            }
        }
        return buffer;
    }

}
