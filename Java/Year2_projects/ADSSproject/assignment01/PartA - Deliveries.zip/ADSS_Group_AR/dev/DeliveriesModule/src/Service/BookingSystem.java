package Service;

import Domain.Shipment;
import Domain.s_status;

import java.util.*;

public class BookingSystem {
    //the stack that holds all pending shipments
    private final Stack<Shipment> pendingShipments;

    //a dictionary that keeps track of all placed orders
    private final Hashtable<Integer, Shipment> bookingsHistory;

    //an instance of the class BookingSystem
    private static BookingSystem currentBookingSystem;

    //private constructor
    private BookingSystem() {
        this.pendingShipments = new Stack<>();
        this.bookingsHistory = new Hashtable<>();

    }

    /**
     * a function that returns the Singleton instance of booking system
     *
     * @return the booking system
     */
    public static BookingSystem getInstance() {
        if (currentBookingSystem == null) {
            currentBookingSystem = new BookingSystem();
        }
        return currentBookingSystem;
    }

    /**
     * a function that receives a new shipment booking
     *
     * @param shipment a new shipment
     */
    public void addNewShipment(Shipment shipment) {
        shipment.updateStatus(s_status.PENDING);
        pendingShipments.push(shipment);
        bookingsHistory.put(shipment.getId(), shipment);
    }

    /**
     * a function that takes all pending bookings and "dumps" them
     *
     * @return a copy of pending shipments Stack
     */
    public Stack<Shipment> getPendingShipments() {
        Stack<Shipment> temp = (Stack<Shipment>) pendingShipments.clone();
        pendingShipments.clear();
        return temp;
    }

    /**
     * checks if there are any pending bookings
     *
     * @return True/False
     */
    public boolean hasBookings() {
        return !pendingShipments.isEmpty();
    }

    /**
     * a function that adds a new self-delivered shipment
     * @param shipment a new self-delivered shipment
     */
    public void addNewSelfShipment(Shipment shipment) {
        shipment.updateStatus(s_status.SELF_DELIVERED);
        bookingsHistory.put(shipment.getId(), shipment);
    }

    public void locateShipment(int shipmentId) {
        Shipment found = this.bookingsHistory.get(shipmentId);
        if (found == null) {
            System.out.println("No shipment found with id " + shipmentId);
        }
        else {
            System.out.println("Shipment number: " + found.getId());
            System.out.println("Shipment status: " + found.getStatus().getDisplayName());

        }
    }

}
