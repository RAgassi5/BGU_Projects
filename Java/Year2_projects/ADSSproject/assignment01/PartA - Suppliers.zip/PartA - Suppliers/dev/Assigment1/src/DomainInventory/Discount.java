package DomainInventory;

public class Discount {
    private int catalogID;
    private int quantityCond;
    private double discountedPrice;

    // Constructor - Initializes a discount with catalog ID, required quantity, and discounted price.
    public Discount(int catalogID, int quantityCond, double discountPrice) {
        this.catalogID = catalogID;
        this.quantityCond = quantityCond;
        this.discountedPrice = discountPrice;
    }

    // Returns a user-friendly string representation of the discount.
    @Override
    public String toString() {
        return "Buy " + quantityCond + "+ items for " + discountedPrice + " ₪ each";
    }

    // Returns the discounted price.
    public double getDiscountedPrice() {
        return discountedPrice;
    }
}
