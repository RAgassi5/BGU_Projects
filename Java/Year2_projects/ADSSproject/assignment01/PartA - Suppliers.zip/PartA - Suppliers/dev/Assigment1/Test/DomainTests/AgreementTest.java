package DomainTests;

import DomainInventory.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AgreementTest {

    @Test
    void addNewProduct_shouldStoreProductPrice() {
        // Test adding a product to an agreement and checking it exists
        Agreement agreement = new PickUpAgreement(1, "Cash", "Warehouse A");
        Product product = new Product(1000, 45.0, 1, "Pasta", "FactoryA", "Food");

        agreement.addNewProduct(product);

        assertTrue(agreement.checkIfProductExists(product.getCatalogID()));
    }

    @Test
    void addNewProduct_multipleTimes_shouldOverwrite() {
        // Test that adding a product with the same catalog ID overwrites the previous one
        Agreement agreement = new PickUpAgreement(1, "Cash", "Warehouse A");
        Product p1 = new Product(1001, 30.0, 1, "Juice", "FactoryB", "Drink");
        Product p2 = new Product(1001, 60.0, 1, "Juice", "FactoryB", "Drink");

        agreement.addNewProduct(p1);
        agreement.addNewProduct(p2);

        assertTrue(agreement.checkIfProductExists(p1.getCatalogID()));
    }

    @Test
    void addNewDiscount_shouldSucceedForExistingProduct() {
        // Test adding a discount for an existing product
        Agreement agreement = new PickUpAgreement(2, "Credit", "Main Branch");
        Product product = new Product(1002, 50.0, 2, "Beer", "FactoryC", "Drink");

        agreement.addNewProduct(product);
        boolean result = agreement.addNewDiscount(product.getCatalogID(), 40.0, 5);

        assertTrue(result);
        Discount discount = agreement.getProductDiscount(product.getCatalogID());
        assertNotNull(discount);
        assertEquals(40.0, discount.getDiscountedPrice());
    }

    @Test
    void addNewDiscount_shouldFailIfDiscountAlreadyExists() {
        // Test that adding a discount fails if one already exists
        Agreement agreement = new PickUpAgreement(2, "Credit", "Main Branch");
        Product product = new Product(1003, 60.0, 2, "Shampoo", "FactoryA", "Cleaning");

        agreement.addNewProduct(product);
        agreement.addNewDiscount(product.getCatalogID(), 50.0, 3);
        boolean secondAttempt = agreement.addNewDiscount(product.getCatalogID(), 45.0, 2);

        assertFalse(secondAttempt);
    }

    @Test
    void removeProduct_shouldRemovePriceAndDiscount() {
        // Test that removing a product also removes its price and discount
        Agreement agreement = new PickUpAgreement(3, "BankTransfer", "Location X");
        Product product = new Product(1004, 20.0, 3, "Soap", "FactoryB", "Cleaning");

        agreement.addNewProduct(product);
        agreement.addNewDiscount(product.getCatalogID(), 15.0, 4);
        agreement.removeProduct(product.getCatalogID());

        assertFalse(agreement.checkIfProductExists(product.getCatalogID()));
        assertNull(agreement.getProductDiscount(product.getCatalogID()));
    }

    @Test
    void getProductDiscount_shouldReturnCorrectDiscount() {
        // Test retrieving a discount for a product
        Agreement agreement = new PickUpAgreement(4, "Cash", "Pickup Point");
        Product product = new Product(1005, 70.0, 4, "Milk", "FactoryC", "Food");

        agreement.addNewProduct(product);
        agreement.addNewDiscount(product.getCatalogID(), 60.0, 2);

        Discount discount = agreement.getProductDiscount(product.getCatalogID());

        assertNotNull(discount);
        assertEquals(60.0, discount.getDiscountedPrice());
    }

    @Test
    void findDiscount_shouldReturnNullIfNotExists() {
        // Test finding a discount that doesn't exist returns null
        Agreement agreement = new PickUpAgreement(5, "Cash", "Depot");

        assertNull(agreement.findDiscount(9999));
    }

    @Test
    void setAgreementStatus_shouldToggleState() {
        // Test toggling the agreement's active/inactive status
        Agreement agreement = new PickUpAgreement(6, "Credit", "Warehouse B");

        boolean initialStatus = agreement.getAgreementStatus();
        agreement.setAgreementStatus();

        assertNotEquals(initialStatus, agreement.getAgreementStatus());

        agreement.setAgreementStatus(); // toggle again
        assertEquals(initialStatus, agreement.getAgreementStatus());
    }

    @Test
    void toString_shouldContainAgreementDetails() {
        // Test that toString includes important details about the agreement
        Agreement agreement = new PickUpAgreement(7, "Cash", "Central Point");
        Product product = new Product(1006, 55.0, 7, "Cookies", "FactoryB", "Food");
        agreement.addNewProduct(product);

        String output = agreement.toString();

        assertTrue(output.contains("Agreement ID"));
        assertTrue(output.contains("Supplier ID"));
        assertTrue(output.contains("Payment Method"));
        assertTrue(output.contains("Catalog ID: " + product.getCatalogID()));
    }
}
