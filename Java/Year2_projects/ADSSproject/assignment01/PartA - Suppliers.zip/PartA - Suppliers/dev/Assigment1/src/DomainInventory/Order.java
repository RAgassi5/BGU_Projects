package DomainInventory;

import java.util.ArrayList;
import java.util.Date;
import java.time.LocalDate;

import static java.time.LocalDate.*;

public class Order {

    public class orderItem{
        private int quantity;
        private double price;
        private String name;
        private int productID;

        // Constructor for orderItem
        public orderItem(int quantity, double price,String name,int productID){
            this.quantity = quantity;
            this.price = price;
            this.name = name;
            this.productID = productID;
        }
        // Getters
        public int getProductId() {return productID;}
        public int getQuantity() {return quantity;}
        public double getPrice() {return price;}
        public String getName() {return name;}

        // Update the quantity
        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        // Calculate total price for this item
        public double getCalcPrice() {
            return price*quantity;
        }
    }
    // Static counter for generating unique order IDs
    static int orderCounter = 1 ;

    private int orderID;
    private Date orderDate;
    private Date orderReceivingDate;
    private int supplierID;
    private boolean orderStatus;
    private ArrayList<orderItem> products;
    private String contactPhoneNumber;
    private double totalPrice ;
    private String orderType = "";

    // Constructor for creating a new order
    public Order(int supplierID,String contactPhoneNumber){
        this.orderID = orderCounter++;
        this.supplierID = supplierID;
        this.contactPhoneNumber = contactPhoneNumber;
        this.orderStatus = false;
        this.totalPrice = 0;
        this.products = new ArrayList<orderItem>();
    }
    // Getters and Setters
    public int getOrderID() {return orderID;}
    public boolean getOrderStatus() {return orderStatus;}
    public String getOrderType(){return orderType;}
    private void setOrderType(String orderType){this.orderType = orderType;}
    public void setOrderStatus() {
        this.orderReceivingDate = new Date();
        this.orderStatus = true;}

    // Add a product to the order
    public boolean addProductToOrder(Product product, int quantity,double price){ // add product to order
        orderItem newItem = new orderItem(quantity,price,product.getProductName(),product.getProductID());
        if(orderType == null) setOrderType(product.getProductType());
        editTotalPrice(newItem.getCalcPrice());
        products.add(newItem);
        return true;
    }

    // Remove a product from the order by product ID
    public void removeProductFromOrder(int productID){
        orderItem removedItem = findOrderItem(productID);
        products.remove(removedItem);
    }

    // Update quantity of a specific product
    public void editItemQuantity(int quantity,int productId){
        orderItem editItem = findOrderItem(productId);
        double oldPrice = editItem.getCalcPrice();
        editItem.setQuantity(quantity);
        double newPrice = editItem.getCalcPrice();
        editTotalPrice(newPrice - oldPrice);
    }

    // Internal method to edit total price
    private void editTotalPrice(double amount){
        this.totalPrice += amount;
    }

    public boolean checkIfProductInList(int productID){
        if (findOrderItem(productID) == null) return false;
        return true;
    }

    // Find a product in the order by product ID
    public orderItem findOrderItem(int productID){ //find the product in List
        for(orderItem i : products){
            if((i.getProductId()) == productID){
                return i;
            }
        }
        return null;
    }

    // Remove an item from the order (by object)
    public boolean removeItemFromOrder(orderItem editItem){
        editTotalPrice(editItem.getCalcPrice());
        products.remove(editItem);
        return true;
    }
    // Update the contact phone number
    public void editContactPhoneNumber(String  PhoneNumber){
        contactPhoneNumber = PhoneNumber;
    }

    // Set and get order dates
    public void setOrderDate(Date orderDate){
        this.orderDate = orderDate;
    }
    public Date getOrderDate(){return orderDate;}
    public Date getOrderReceivingDate(){return orderReceivingDate;}
    public void setOrderReceivingDate(Date orderReceivingDate){
        this.orderReceivingDate = orderReceivingDate;
    }

    // Nicely format the order details for printing
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("----- Order Details -----\n");
        sb.append("Order ID: ").append(orderID).append("\n");
        sb.append("Supplier ID: ").append(supplierID).append("\n");
        sb.append("Contact Phone Number: ").append(contactPhoneNumber).append("\n");
        sb.append("Order Status: ").append(orderStatus ? "Completed" : "In Progress").append("\n");
        sb.append("Order Date: ").append(orderDate != null ? orderDate : "Not Set").append("\n");
        sb.append("Receiving Date: ").append(orderReceivingDate != null ? orderReceivingDate : "Not Set").append("\n");
        sb.append("Total Price: ").append(totalPrice).append(" ₪\n");
        sb.append("Products in Order:\n");

        if (products == null || products.isEmpty()) {
            sb.append("  No products in this order.\n");
        } else {
            for (orderItem item : products) {
                sb.append("  - Product: ").append(item.getName()).append("\n");
                sb.append("    Quantity: ").append(item.getQuantity()).append("\n");
                sb.append("    Unit Price: ").append(item.getPrice()).append("\n");
                sb.append("    Total Price: ").append(item.getCalcPrice()).append("\n");
            }
        }

        sb.append("--------------------------\n");

        return sb.toString();
    }

    // Get the total price of the order
    public double getOrderPrice(){return totalPrice;}

    // Get quantity of a specific product
    public int getProductQuantity(int productID){
        orderItem item = findOrderItem(productID);
        return item.getQuantity();
    }

    // Get the supplier ID of this order
    public int getOrderSupplierID(){
        return supplierID;
    }



}


