package DomainInventory;

import java.util.*;

public class Supplier {
    // Static counter to generate unique supplier IDs
    static int IDcounter = 1;
    private int supplierID;
    private String supplierName;
    private String bankAccountNumber;
    private ArrayList<Contact> contactsDetails;
    private Set<Tuple> productTypes;
    private ArrayList<Agreement> agreements;
    private Map<Integer,Product> productsMap;
    private Set<Tuple> manufacturers;
    private boolean isActive;

    // Constructor to create a new Supplier
    public Supplier(String supplierName,String bankAccountNumber) {
        this.supplierID = IDcounter++;
        this.supplierName = supplierName;
        this.bankAccountNumber = bankAccountNumber;
        contactsDetails =new ArrayList<>();
        productTypes =  new HashSet<>();
        agreements = new ArrayList<>();
        productsMap = new HashMap<>();
        manufacturers = new HashSet<>();
        isActive = true;
    }

    // Getters
    public int getSupplierID() {return supplierID;}
    public String getSupplierName() {return supplierName;}
    public String getBankAccountNumber() {return bankAccountNumber;}
    public ArrayList<Contact> getContactDetails() {return contactsDetails;}
    public boolean isActive() {return isActive;}
    public Map<Integer,Product> getProductsMap() {return productsMap;}



    // Get all product IDs that belong to this supplier
    public ArrayList<Integer> getProductsIDs(){
        ArrayList<Integer> productsIDs = new ArrayList<>();
        for(Product product : productsMap.values()){
            productsIDs.add(product.getProductID());
        }
        return productsIDs;
    }
    // Setters
    public void setBankAccountNumber(String bankAccountNumber){this.bankAccountNumber = bankAccountNumber;}
    public void setActive() {this.isActive = true;}
    public void setUnActive() {this.isActive = false;}

    // Product Types Management
    public void addProductType(String productType) {
        addToTupleSet(productTypes,productType);
    }
    public ArrayList<String>  getProductTypes() {return  extractNames(productTypes);}

    // Add a contact to the supplier
    public void addContact(String name, String phoneNumber) {
        Contact newContact = new Contact(name,phoneNumber);
        contactsDetails.add(newContact);
    }

    // Agreements Management
    public void addAgreement(Agreement agreement) {agreements.add(agreement);}
    public Agreement findAgreement(int agreementID) {
        for (Agreement a : agreements) {
            if (a.getAgreementID() == agreementID) {
                return a;
            }
        }
        return null;
    }
    public ArrayList<Agreement> getAllAgreements() {
        return this.agreements;
    }


    // Products Management
    public boolean addProductToMap(Product product) {
        if(!productsMap.containsKey(product.getCatalogID())){
            productsMap.put(product.getCatalogID(),product);
            return true;
        }
        return false;
    }
    public Product removeProductFromMap(int catalogID) {
        for(Product product : productsMap.values()) {
            if(product.getCatalogID() == catalogID){
                removeFromTupleSet(manufacturers,product.getManufacturer());
                removeFromTupleSet(productTypes,product.getProductType());
                productsMap.remove(catalogID);
                return product;
            }
        }
       return null;
    }
    public boolean hasProductWithID(int productID) {
        for (Product p : productsMap.values()) {
            if (p.getProductID() == productID) return true;
        }
        return false;
    }
    public Product getProduct(int catalogID){return productsMap.get(catalogID);}


    // Manufacturers Management
    public ArrayList<String> getManufacturers() {return extractNames(manufacturers);}
    public void addManufacturer(String manufacturer) {
        addToTupleSet(manufacturers,manufacturer);
    }







    // Utils for working with Tuple sets
    public static ArrayList<String> extractNames(Set<Tuple> tupleSet) {
        ArrayList<String> names = new ArrayList<>();
        for (Tuple<String, Integer> tuple : tupleSet) {
            names.add(tuple.getFirst());
        }
        return names;
    }

    public static Tuple containsName(Set<Tuple> tupleSet, String name) {
        for (Tuple<String, Integer> tuple : tupleSet) {
            if (tuple.getFirst().equals(name)) {
                return tuple;
            }
        }
        return null;
    }

    public void removeFromTupleSet(Set<Tuple> tupleSet, String name) {
        Tuple<String, Integer> tuple = containsName(tupleSet, name);
        if (tuple != null) {
            if (tuple.getSecond().equals(1)) {
                tupleSet.remove(tuple);
            } else {
                tuple.decrementSecond();
            }
        }
    }

    public void addToTupleSet(Set<Tuple> tupleSet, String name) {
        Tuple<String, Integer> existing = containsName(tupleSet, name);
        if (existing != null) {
            existing.incrementSecond();
        } else {
            tupleSet.add(new Tuple<>(name, 1));
        }
    }

    // Nicely format all supplier details
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Supplier ID: ").append(supplierID).append("\n");
        sb.append("Name: ").append(supplierName).append("\n");
        sb.append("Bank Account: ").append(bankAccountNumber).append("\n");
        sb.append("Active: ").append(isActive ? "Yes" : "No").append("\n");

        sb.append("Contacts:\n");
        for (Contact c : contactsDetails) {
            sb.append("  - ").append(c).append("\n");
        }

        sb.append("Manufacturers:\n");
        for (String m : getManufacturers()) {
            sb.append("  - ").append(m).append("\n");
        }

        sb.append("Product Types:\n");
        for (String pt : getProductTypes()) {
            sb.append("  - ").append(pt).append("\n");
        }

        sb.append("Agreements:\n");
        for (Agreement a : agreements) {
            sb.append("  - ").append(a).append("\n");
        }

        sb.append("Products:\n");
        for (Product p : productsMap.values()) {
            sb.append("  - ").append(p).append("\n");
        }

        return sb.toString();
    }

    // Get discount on a product from agreements
    public Discount getDiscountOnProductInAgreement(int suplierID,int catalogID) {
        for (Agreement agreement : getAllAgreements()){
            if (agreement.checkIfProductExists(catalogID))
                    return agreement.getProductDiscount(catalogID);
        }
        return null;

    }





    }
