package Domain;

public class Driver {
    private String driverName;
    private String[] availableLicenses;
    private driver_status driverStatus;

    public Driver(String driverName) {
        this.driverName = driverName;
        this.availableLicenses = new String[0];
        this.driverStatus = driver_status.FREE;
    }

    /**
     * adds a license to a driver
     *
     * @param license a string representing the license to be added
     */
    public void addLicense(String license) {
        String[] temp = new String[this.availableLicenses.length + 1];
        System.arraycopy(this.availableLicenses, 0, temp, 0, this.availableLicenses.length);
        temp[this.availableLicenses.length] = license;
        this.availableLicenses = temp;
    }

    /**
     * checks if the driver has the required license
     *
     * @param license a string representing the required license
     * @return bool True/False
     */
    public boolean getLicense(String license) {
        for (int i = 0; i < this.availableLicenses.length; i++) {
            if (this.availableLicenses[i].equals(license)) {
                return true;
            }
        }
        return false;
    }

    /**
     * a getter function for the driver's name
     *
     * @return the driver's name
     */
    public String getDriverName() {
        return this.driverName;
    }

    /**
     * a getter function for the driver's status
     */
    public driver_status getDriverStatus() {
        return this.driverStatus;
    }

    /**
     * a setter function for the driver's status
     * @param driverStatus driver's status
     */
    public void setDriverStatus(driver_status driverStatus) {
        this.driverStatus = driverStatus;
    }

    /**
     * print function for Driver
     */
    public void printDriver() {
        System.out.println(this.driverName + this.driverStatus.getDriver_status());

    }
}

