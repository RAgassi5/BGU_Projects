#include "Fighter.h"


Fighter::Fighter(int max_health, int damage): Player("Fighter", max_health, damage) {
}

Fighter::~Fighter() {
}

void Fighter::print() const {
    std::cout << "fighter";
}

void Fighter::LetsFight(Monster &other) {
    other.CanFightFighter();
}

bool Fighter::activateSpecialtyFighter() {
    if (this->specialtySwitch == 3) {
        this->reset_Specialty();
        return true;
    }
    this->set_Specialty();
    return false;
}

bool Fighter::activateSpecialtySorcerer() {
    return false;
}

void Fighter::set_Specialty() {
    if (this->specialtySwitch == 3) {
        this->specialtySwitch = 3;
    } else {
        ++(this->specialtySwitch);
    }
}
