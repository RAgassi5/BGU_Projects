package Data;

public enum Status {
    Success, Failure
}
