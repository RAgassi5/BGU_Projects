package DataInventory;

import DomainInventory.Supplier;

import java.util.ArrayList;
// Interface for managing Supplier objects
public interface ISupplierRepository {
    // Insert a new supplier into the repository
    public void insertSupplier(Supplier supplier);
    // Get (pull) a supplier by their supplier ID
    public Supplier pullSupplier(int supplierID);
    // Get a list of all suppliers
    public ArrayList<Supplier> getAllSuppliers();
    // Get a list of supplier IDs that offer a specific product
    public ArrayList<Integer> getSuppliersByProductID(int productID);
    // Get a supplier object by supplier ID
    public Supplier getSupplier(int supplierID);


}


