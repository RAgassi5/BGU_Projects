package Domain;

import java.time.LocalDate;

public abstract class ADiscount {
    //Fields:
    protected double discountRate;
    protected LocalDate startDate;
    protected LocalDate endDate;

    //constructor:
    public ADiscount(double rate, LocalDate sDate, LocalDate eDate) {
        this.discountRate = rate;
        this.startDate = sDate;
        this.endDate = eDate;
    }

    //Methods:
    public LocalDate getStartDate() {
        return this.startDate; //immutable
    }

    public LocalDate getEndDate() {
        return this.endDate;
    }

    public double getDiscountRate() {
        return this.discountRate;
    }


    public abstract boolean hasDiscount(ItemTemplate item);
}
