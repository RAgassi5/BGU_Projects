package Presentation;

import Service.BootStarter;

import java.util.Scanner;

public class InitializationMenu {
    private final BootStarter bootStarter;

    public InitializationMenu() {
        bootStarter = new BootStarter();
    }

    public void run(Scanner scanner) {
        int choice;
        do {
            choice = displayInitializationMenu(scanner);
            switch (choice) {
                case 1:
                    break;
                case 2:
                    bootStarter.start();
            }

        } while (choice != 1 && choice != 2);
    }


    public static int displayInitializationMenu(Scanner scanner) {
        int buffer;
        while (true) {
            try {
                System.out.println("Welcome!\nHow would you like to initialize the system?");
                System.out.println("1. Empty Initialization");
                System.out.println("2. Preset Initialization");
                System.out.print("Enter your choice: ");
                buffer = scanner.nextInt();
                scanner.nextLine();
                if (buffer == 1) {
                    break;
                } else if (buffer == 2) {
                    break;
                } else {
                    System.out.println("Invalid input, please select from the given options");
                }
            } catch (Exception e) {
                System.out.println("Invalid input, please select from the given options");
                scanner.nextLine();
            }
        }
        return buffer;
    }
}
