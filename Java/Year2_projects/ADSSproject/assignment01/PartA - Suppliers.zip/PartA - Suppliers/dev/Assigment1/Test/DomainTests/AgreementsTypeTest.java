package DomainTests;

import DomainInventory.DeliverableAgreement;
import DomainInventory.FixedDeliveryAgreement;
import DomainInventory.FlexibleDeliveryAgreement;
import org.junit.jupiter.api.Test;
import java.time.DayOfWeek;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class AgreementsTypeTest {

    @Test
    void testFlexibleDeliveryAgreementType() {
        FlexibleDeliveryAgreement flexibleAgreement = new FlexibleDeliveryAgreement(1, "Cash", 5);
        assertEquals("Flexible Delivery", flexibleAgreement.getAgreementType());
    }

    @Test
    void testFixedDeliveryAgreementType() {
        ArrayList<DayOfWeek> supplyDays = new ArrayList<>();
        supplyDays.add(DayOfWeek.MONDAY);
        supplyDays.add(DayOfWeek.WEDNESDAY);

        FixedDeliveryAgreement fixedAgreement = new FixedDeliveryAgreement(2, "Credit", supplyDays);
        assertEquals("FixedDelivery", fixedAgreement.getAgreementType());
    }

    @Test
    void testDeliverableAgreementType_stub() {
        DeliverableAgreement dummyAgreement = new DeliverableAgreement(3, "BankTransfer") {
        };

        assertEquals("Deliverable", dummyAgreement.getAgreementType());
    }
}
