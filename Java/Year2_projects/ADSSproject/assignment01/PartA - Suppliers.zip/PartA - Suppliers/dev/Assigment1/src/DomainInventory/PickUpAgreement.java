package DomainInventory;

public class PickUpAgreement extends Agreement {
    private String supplierAddress;

    // Constructor - Initializes a PickUpAgreement and saves the supplier address.
    public PickUpAgreement(int supplierID, String paymentMethod,String supplierAddress) {
        super(supplierID, paymentMethod);
        this.supplierAddress = supplierAddress;
    }
}
