package DataInventory;

import DomainInventory.Product;
import java.util.HashMap;

public class ProductRepository implements IProductRepository {
    private final HashMap<Integer, HashMap<Integer,Product>> productsByProductID = new HashMap<>();
    private final HashMap<String,Integer> productsByProductName = new HashMap<>();

    @Override
    public Product getProductByPSId(int ProductId, int supplierID) {
        HashMap<Integer, Product> supplierMap = productsByProductID.get(ProductId);
        if (supplierMap == null) return null;
        return supplierMap.get(supplierID);
    }

    @Override
    public HashMap<Integer, Product> getProductByProductId(int productId) {
        return productsByProductID.getOrDefault(productId, new HashMap<>());
    }
    public int getProductIDByProductName(String ProductName) {
        if(productsByProductName.containsKey(ProductName)) return productsByProductName.get(ProductName);
        return -1;
    }

    @Override
    public void addProductToRepo(Product product) {
        int productID = product.getProductID();
        int supplierID = product.getSupplierID();

        HashMap<Integer, Product> supplierMap = productsByProductID.get(productID);
        if (supplierMap == null) {
            supplierMap = new HashMap<>();
            productsByProductID.put(productID, supplierMap);
        }
        supplierMap.put(supplierID, product);

        productsByProductName.put(product.getProductName(), productID);
    }

    @Override
    public void deleteProductFromRepo(Product product) {
        int productID = product.getProductID();
        int supplierID = product.getSupplierID();

        HashMap<Integer, Product> supplierMap = productsByProductID.get(productID);
        if (supplierMap != null) {
            supplierMap.remove(supplierID);
            if (supplierMap.isEmpty())
                productsByProductID.remove(productID);
        }
        productsByProductName.remove(product.getProductName());
    }



}
