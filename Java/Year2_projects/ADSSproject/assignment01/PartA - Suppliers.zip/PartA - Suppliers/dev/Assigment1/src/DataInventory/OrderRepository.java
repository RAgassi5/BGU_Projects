package DataInventory;

import DomainInventory.Order;
import java.util.ArrayList;
import java.util.HashMap;

public class OrderRepository implements IOrderRepository {
    private HashMap<Integer, Order> ordersByOrderID = new HashMap<>();

    @Override
    public void addOrderToRepository(Order order) {
        ordersByOrderID.put(order.getOrderID(), order);
    }

    @Override
    public Order pollOrder(int orderID) {
        return ordersByOrderID.get(orderID);
    }

    @Override
    public boolean getOrderStatus(int orderID) {
        Order order = ordersByOrderID.get(orderID);
        return order.getOrderStatus();
    }

    @Override
    public void deleteOrderFromRepo(int orderID) {
        ordersByOrderID.remove(orderID);
    }

    @Override
    public ArrayList<Order> getAllActiveOrders() {
        ArrayList<Order> activeOrders = new ArrayList<>();
        for (Order order : ordersByOrderID.values()) {
            if (!order.getOrderStatus()) {
                activeOrders.add(order);
            }
        }
        return activeOrders;
    }
}
