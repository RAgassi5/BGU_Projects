package ServiceInventory;

import DataInventory.*;
import DomainInventory.*;

import java.time.DayOfWeek;
import java.util.ArrayList;

public class SupplierService {
    private IProductRepository productRepo;
    private ISupplierRepository supplierRepo;


    // This is the constructor for the SupplierService class.
    // It requires two dependencies to work: productRepo and supplierRepo.
    public SupplierService(IProductRepository productRepo, ISupplierRepository supplierRepo) {
        this.productRepo = productRepo;
        this.supplierRepo = supplierRepo;
    }

    // This method checks if a supplier exists in the repository.
    public boolean doesSupplierExist(int supplierId) {
        // Calls the supplier repository to get the supplier by ID.
        // If the result is not null, it means the supplier exists.
        return (supplierRepo.getSupplier(supplierId) != null);
    }

    // This method creates a new supplier and adds it to the supplier repository.
    public int createSupplier(String supplierName,String bankAccountNumber) {
        Supplier newSupplier = new Supplier(supplierName, bankAccountNumber);
        supplierRepo.insertSupplier(newSupplier);
        return newSupplier.getSupplierID();
    }

    // Adds a new product to a supplier, and updates its manufacturer and product type.
    public void addProductToSupplier(int supplierID, Product product, String type, String manufacturer) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        supplier.addManufacturer(manufacturer);
        supplier.addProductType(type);
        supplier.addProductToMap(product);
    }

    // Changes the active status of a supplier: if active, deactivates; if inactive, activates.
    // Returns true if supplier was deactivated, false if activated.
    public boolean changeStatusService(int supplierID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        if (checkSupplierStatus(supplierID)) {
            supplier.setUnActive();
            return true; // was active => now deactivated
        } else {
            supplier.setActive();
            return false; // was inactive => now activated
        }

    }

    // Adds a new contact (name and phone) to a specific supplier.
    public void addContactToSupplier(int supplierID, String name, String phone) {
        Supplier s = supplierRepo.pullSupplier(supplierID);
        s.addContact(name, phone);
    }

    // Checks if a supplier is currently active.
    // Returns true if active, false if inactive.
    public boolean checkSupplierStatus(int supplierID) {
         return supplierRepo.pullSupplier(supplierID).isActive();
    }

    // Returns a list of all agreements associated with a specific supplier.
    public ArrayList<Agreement> getAllAgreementsBySupplier(int supplierID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        return  supplier.getAllAgreements();
    }

    // Adds an agreement to a specific supplier.
    public void addAgreementToSupplier(int supplierID, Agreement agreement) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        supplier.addAgreement(agreement);
    }

    // Creates a new PickUp agreement for a supplier if valid, adds it to the supplier, and returns the agreement ID.
    public int CreatePickUpAgreement(String paymentMethod,int supplierID,String adress ) {
        PickUpAgreement newPUA = new PickUpAgreement(supplierID,adress,paymentMethod);
        addAgreementToSupplier(supplierID,newPUA);
        return newPUA.getAgreementID();
    }

    // Creates a new Fixed Delivery agreement for a supplier and returns the agreement ID.
    public int CreateFixedAgreement(String paymentMethod, int supplierID, ArrayList<DayOfWeek> supplyDays ) {
        FixedDeliveryAgreement newFAA = new FixedDeliveryAgreement(supplierID,paymentMethod,supplyDays);
        addAgreementToSupplier(supplierID,newFAA);
        return newFAA.getAgreementID();
    }

    // Creates a new Flexible Delivery agreement for a supplier and returns the agreement ID.
    public int CreateFlexibleAgreement(String paymentMethod,int supplierID,int supplyDays ) {
        FlexibleDeliveryAgreement newFlexA = new FlexibleDeliveryAgreement(supplierID,paymentMethod,supplyDays);
        addAgreementToSupplier(supplierID,newFlexA);
        return newFlexA.getAgreementID();
    }

    // Checks if it is valid to create a new agreement for a supplier by verifying no conflicting active agreements exist.
    // Returns true if creation is allowed, false otherwise.
    public boolean checkValidAgreement(String type1,int supplierID) {
        ArrayList<Agreement> agreements = supplierRepo.getSupplier(supplierID).getAllAgreements();
        for(Agreement agreement : agreements){
            if (agreement.getAgreementType().equals(type1) && agreement.getAgreementStatus())
                return false;
        }
        return true;
    }

    // Adds a new product to the supplier and to the system repository.
    // If a matching agreement exists, the product is also added to that agreement.
    // Always returns the created Product object.
    public Product addNewProductToAgreement(int catalogID, double price, int supplierID, String productName, int agreementID,String manufacturer,String type) {
        int productID = productRepo.getProductIDByProductName(productName);
        Product product;
        if(productID == -1)
            product = new Product(catalogID, price, supplierID, productName,manufacturer,type);
        else
            product = new Product(productID,catalogID, price, supplierID, productName,manufacturer,type);
        addProductToSupplier(supplierID,product,type,manufacturer);
        productRepo.addProductToRepo(product);
        Agreement agreement = supplierRepo.pullSupplier(supplierID).findAgreement(agreementID);
        if (agreement != null)
            agreement.addNewProduct(product);
        return product;
    }

    // Deletes a product from a supplier's agreement (if it exists) and from the product repository.
    // First removes the product from the agreement if found, then removes it from the supplier and system.
    public void deleteProductFromSystem(int catalogID,int agreementID,int supplierID){
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        Agreement agreement = supplier.findAgreement(agreementID);
        if(agreement != null)
            agreement.removeProduct(catalogID);
        productRepo.deleteProductFromRepo(supplier.removeProductFromMap(catalogID));
    }

    // Checks if a product exists for a supplier by catalog ID.
    public boolean checkIfProductExist(int supplierID, int catalogID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        return supplier.getProduct(catalogID) != null;
    }




    // Adds a discounted price for a product inside an agreement, if the product and agreement exist.
    // Returns true if the discount was successfully added, false otherwise.
    public boolean addDiscountedProduct(int catalogID,double percentage,int agreementID,int supplierID,int quantity) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        Agreement agreement = supplier.findAgreement(agreementID);
        if (!agreement.checkIfProductExists(catalogID))
            return false;
        Product product = supplier.getProduct(catalogID);
        agreement.addNewDiscount(catalogID,product.getPrice()*(100-percentage)/100,quantity);
        return true;
    }


    // Changes the status (active/inactive) of an agreement.
    // Returns the new status: true = active, false = inactive.
    public boolean changeAgreementStatus(int agreementID, int supplierID) {
        Agreement agreement = supplierRepo.pullSupplier(supplierID).findAgreement(agreementID);
        agreement.setAgreementStatus();
        return agreement.getAgreementStatus();
    }

    // Fetches the current status (active/inactive) of an agreement.
    public boolean getAgreementStatus(int agreementID,int supplierID) {
        Agreement agreement = supplierRepo.pullSupplier(supplierID).findAgreement(agreementID);
        return agreement.getAgreementStatus();
    }

    // Changes the price of a product inside a supplier by its catalog ID.
    // If the product is found, updates its price.
    public void changeProductPrice(int supplierID,int catalogID,double price){
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        for( Product product : supplier.getProductsMap().values()){
            if (product.getCatalogID() == catalogID){
                product.setPrice(price);
                return;
            }
        }
    }

    // Returns the supplier object itself, letting the UI layer decide what to do with it.
    public Supplier getSupplier(int supplierID) {
        return supplierRepo.pullSupplier(supplierID);
    }

    // Returns a list of suppliers ID who supply a given product ID.
    public ArrayList<Integer> getProductSuppliers(int productID) {
        return supplierRepo.getSuppliersByProductID(productID);
    }

    // Returns a list of IDs for all active suppliers by checking their active status.
    public ArrayList<Integer> getActiveSuppliers() {
        ArrayList<Integer> activeSuppliers = new ArrayList<>();
        for(Supplier supplier :supplierRepo.getAllSuppliers())
            if(supplier.isActive())
                activeSuppliers.add(supplier.getSupplierID());
        return activeSuppliers;
    }

    // Returns a list of product types supplied by the given supplier ID.
    public ArrayList<String> getAllTypes(int supplierID) {
       return supplierRepo.pullSupplier(supplierID).getProductTypes();
    }

    // Returns a list of manufacturers associated with the given supplier ID.
    public ArrayList<String> getAllManufacturers(int supplierID) {
        return supplierRepo.pullSupplier(supplierID).getManufacturers();
    }

    // Changes the bank account number of the supplier with the given ID.
    public void changeBankAccountNumber(String bankAccountNumber,int supplierID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        supplier.setBankAccountNumber(bankAccountNumber);
    }

    // Returns a list of product IDs that the given supplier supplies.
    public ArrayList<Integer> getProductsBySupplier(int supplierID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        return supplier.getProductsIDs();
    }

    // Checks if an agreement with the given ID exists for the specified supplier.
    // Returns true if the agreement does NOT exist.
    public boolean checkIfAgreementExists(int agreementID, int supplierID) {
        Supplier supplier = supplierRepo.pullSupplier(supplierID);
        Agreement agreement = supplier.findAgreement(agreementID);
        return agreement == null;
    }

    // Retrieves the discount for a specific product from a given supplier.
    public Discount getSupplierProductDiscount(int suplierID,int catalogID) {
        Supplier supplier = supplierRepo.pullSupplier(suplierID);
        return supplier.getDiscountOnProductInAgreement(suplierID, catalogID);
    }

}
