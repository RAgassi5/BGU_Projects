package DataInventory;

import DomainInventory.Order;

import java.util.ArrayList;

// Interface for managing Order objects
public interface IOrderRepository {
    // Add a new order to the repository
    public void addOrderToRepository(Order order);
    // Get an order by its ID (could return null if not found)
    public Order pollOrder(int OrderID);
    // Check if an order with a given ID is completed
    public boolean getOrderStatus(int OrderID);
    // Remove an order from the repository by its ID
    public void deleteOrderFromRepo(int OrderID);
    // Get a list of all orders that are still active (not completed)
    public ArrayList<Order> getAllActiveOrders();
}
