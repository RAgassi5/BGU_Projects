package SetUp;

import ServiceInventory.OrderService;
import ServiceInventory.SupplierService;
import DomainInventory.Product;

import java.time.DayOfWeek;
import java.util.*;

public class SystemInitializer {
    private final SupplierService supplierService;
    private final OrderService orderService;
    private final Random random = new Random();

    private final String[] paymentMethods = {"Credit", "Cash", "BankTransfer"};
    private final String[] manufacturers = {"FactoryA", "FactoryB", "FactoryC"};
    private final String[] productTypes = {"Food", "Drink", "Cleaning"};

    private final List<Integer> supplierIDs = new ArrayList<>();
    private final Map<Integer, List<Integer>> agreementsBySupplier = new HashMap<>();

    private static final int SUPPLIER_COUNT = 10;
    private static final int TOTAL_PRODUCTS = 30;
    private static final int ORDER_COUNT = 10;

    public SystemInitializer(SupplierService supplierService, OrderService orderService) {
        this.supplierService = supplierService;
        this.orderService = orderService;
    }

    public void initializeSystem() {
        System.out.println("🔧 Initializing system...");

        createSuppliers();
        assignAgreementsToSuppliers();
        generateProducts();
        createOrders();

        System.out.println("🎉 Initialization complete: " + SUPPLIER_COUNT + " suppliers, " +
                TOTAL_PRODUCTS + " product entries, " + ORDER_COUNT + " orders.");
    }

    private void createSuppliers() {
        for (int i = 1; i <= SUPPLIER_COUNT; i++) {
            int supplierID = supplierService.createSupplier("Supplier" + i, "00000000" + i);
            supplierIDs.add(supplierID);
        }
    }

    private void assignAgreementsToSuppliers() {
        for (int i = 0; i < SUPPLIER_COUNT; i++) {
            int supplierID = supplierIDs.get(i);
            List<Integer> agreements = new ArrayList<>();

            if (i < 3) {
                int id = createAgreement(supplierID, "PickUp");
                if (id != -1) agreements.add(id);
            } else if (i < 6) {
                int fixed = createAgreement(supplierID, "FixedDelivery");
                int flex = createAgreement(supplierID, "FlexibleDelivery");
                if (fixed != -1) agreements.add(fixed);
                if (flex != -1) agreements.add(flex);
            } else if (i < 9) {
                int flex = createAgreement(supplierID, "FlexibleDelivery");
                if (flex != -1) agreements.add(flex);
            } else {
                List<String> types = Arrays.asList("FixedDelivery", "PickUp", "FlexibleDelivery");
                Collections.shuffle(types);
                for (String type : types) {
                    int id = createAgreement(supplierID, type);
                    if (id != -1) {
                        agreements.add(id);
                        break;
                    }
                }
            }

            agreementsBySupplier.put(supplierID, agreements);
        }
    }

    private void generateProducts() {
        int created = 0;
        while (created < TOTAL_PRODUCTS) {
            int supplierID = supplierIDs.get(random.nextInt(SUPPLIER_COUNT));
            List<Integer> agreements = agreementsBySupplier.get(supplierID);
            if (agreements == null || agreements.isEmpty()) continue;

            int agreementID = agreements.get(random.nextInt(agreements.size()));
            String productName = generateProductName(created);
            double price = 20 + random.nextInt(80);
            String manufacturer = manufacturers[random.nextInt(manufacturers.length)];
            String type = productTypes[random.nextInt(productTypes.length)];
            int catalogID = 1000 + created;

            Product product = supplierService.addNewProductToAgreement(
                    catalogID, price, supplierID, productName, agreementID, manufacturer, type);

            if (product == null) continue;

            if (random.nextBoolean()) {
                int quantity = 5 + random.nextInt(6);
                double discount = price * (0.8 + random.nextDouble() * 0.1);
                supplierService.addDiscountedProduct(catalogID, discount, agreementID, supplierID, quantity);
            }

            created++;
        }
    }

    private String generateProductName(int index) {
        String[] baseNames = {"Tomatoes", "Pasta", "Detergent", "Cola", "Juice", "Soap", "Shampoo", "Milk", "Cookies", "Beer"};
        return baseNames[index % baseNames.length] + " " + (index / baseNames.length + 1);
    }

    private void createOrders() {
        for (int i = 0; i < ORDER_COUNT; i++) {
            int supplierID = supplierIDs.get(random.nextInt(supplierIDs.size()));
            List<Integer> productIDs = supplierService.getProductsBySupplier(supplierID);
            if (productIDs == null || productIDs.isEmpty()) continue;

            String phone = "05000000" + i;
            int orderID = orderService.createNewOrder(supplierID, phone);

            int numProducts = 1 + random.nextInt(3);
            Collections.shuffle(productIDs);
            Set<Integer> used = new HashSet<>();

            for (int productID : productIDs) {
                if (used.add(productID)) {
                    int quantity = 1 + random.nextInt(10);
                    orderService.addProductToOrder(productID, orderID, quantity);
                }
                if (used.size() >= numProducts) break;
            }
        }
    }

    private int createAgreement(int supplierID, String type) {
        String payment = paymentMethods[random.nextInt(paymentMethods.length)];
        return switch (type) {
            case "FixedDelivery" -> {
                ArrayList<DayOfWeek> days = new ArrayList<>();
                days.add(DayOfWeek.of(1 + random.nextInt(7)));
                days.add(DayOfWeek.of(1 + random.nextInt(7)));
                yield supplierService.CreateFixedAgreement(payment, supplierID, days);
            }
            case "PickUp" -> supplierService.CreatePickUpAgreement(payment, supplierID, "PickupAddress" + supplierID);
            case "FlexibleDelivery" -> {
                int supplyDays = 2 + random.nextInt(5);
                yield supplierService.CreateFlexibleAgreement(payment, supplierID, supplyDays);
            }
            default -> -1;
        };
    }
}
