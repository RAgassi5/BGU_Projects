package DomainInventory;

public class Tuple<A,B> {
    public final A first;
    private B second;

    // Constructor to create a tuple
    public Tuple(A first, B second) {
            this.first = first;
            this.second = second;
    }
    // Getter for first value
    public A getFirst() {
        return first;
    }

    // Getter for second value
    public B getSecond() {
        return second;
    }

    // Increment the second value if it's an Integer
    public void incrementSecond() {
        if (second instanceof Integer) {
            Integer value = (Integer) second;
            this.second = (B) (Integer) (value + 1);
        } else {
            throw new UnsupportedOperationException("incrementSecond only supported for Integer type");
        }
    }

    // Decrement the second value if it's an Integer (can't go below 0)
    public void decrementSecond() {
        if (second instanceof Integer) {
            Integer value = (Integer) second;
            this.second = (B) (Integer) Math.max(0, value - 1);
        } else {
            throw new UnsupportedOperationException("decrementSecond only supported for Integer type");
        }
    }


    // Pretty print the tuple
    @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }



