package DomainTests;

import DomainInventory.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductTest {

    @Test
    void testProductCreation_basicConstructor() {
        // Test creating a product using the basic constructor
        Product product = new Product(1000, 45.0, 1, "Tomato", "FactoryA", "Food");

        assertEquals(1000, product.getCatalogID());
        assertEquals(45.0, product.getPrice());
        assertEquals(1, product.getSupplierID());
        assertEquals("Tomato", product.getProductName());
        assertEquals("FactoryA", product.getManufacturer());
        assertEquals("Food", product.getProductType());
    }

    @Test
    void testProductCreation_fullConstructor() {
        // Test creating a product using the full constructor (with productID given manually)
        Product product = new Product(2000, 1000, 30.0, 2, "Pasta", "FactoryB", "Food");

        assertEquals(2000, product.getProductID());
        assertEquals(1000, product.getCatalogID());
        assertEquals(30.0, product.getPrice());
    }

    @Test
    void testSetAndGetSupplierID() {
        // Test setting and getting the supplier ID
        Product product = new Product(1001, 50.0, 3, "Milk", "FactoryC", "Drink");


        assertEquals(3, product.getSupplierID());
    }

    @Test
    void testSetAndGetPrice() {
        // Test setting and getting the product price
        Product product = new Product(1002, 20.0, 4, "Juice", "FactoryA", "Drink");

        product.setPrice(25.0);

        assertEquals(25.0, product.getPrice());
    }

    @Test
    void testGetDiscountedPrice_shouldReturnSameAsPrice() {
        // Test that getDiscountedPrice returns the normal price (no discount logic applied)
        Product product = new Product(1003, 60.0, 5, "Beer", "FactoryB", "Drink");

        assertEquals(60.0, product.getDiscountedPrice(10)); // quantity does not affect price
    }

    @Test
    void testToString_containsAllImportantInfo() {
        // Test that the toString output includes all important fields
        Product product = new Product(1004, 70.0, 6, "Soap", "FactoryC", "Cleaning");

        String output = product.toString();

        assertTrue(output.contains("ProductID"));
        assertTrue(output.contains("Name"));
        assertTrue(output.contains("CatalogID"));
        assertTrue(output.contains("Price"));
        assertTrue(output.contains("Manufacturer"));
        assertTrue(output.contains("Product Type"));
        assertTrue(output.contains("Supplier ID"));
    }
}
