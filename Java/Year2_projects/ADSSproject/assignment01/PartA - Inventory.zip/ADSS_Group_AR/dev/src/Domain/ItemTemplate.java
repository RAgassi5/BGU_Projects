package Domain;

import Data.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ItemTemplate {
    //Fields:
    private static int tIDCounter = 1;
    private final int itemplateID;
    private final String itemName;
    private final String producerName;
    private int shelfAmount;
    private int storageAmount;
    private int totalAmount;
    private double salePrice;
    private int minAmount;


    //Relationship Fields:
    private final Category primary; //Data.Category is immutable after creating template
    private final Category secondary;
    private final Category size;
    private final List<ItemCostPrice> costPrices;
    private final Map<Integer, ItemInstance> Instances;

    //Constructor:
    public ItemTemplate(String iName, String pName, double sPrice, int minAm, Category PrimaryCat,
                 Category SecondaryCat, Category SizeCat) {
        //assuming valid input as described in the Forum.
        this.itemplateID = tIDCounter;
        tIDCounter++;
        this.itemName = iName;
        this.producerName = pName;
        this.shelfAmount = 0;
        this.storageAmount = 0;
        this.totalAmount = 0;
        this.salePrice = sPrice;
        this.minAmount = minAm;

        //initialize object fields
        this.primary = PrimaryCat;
        this.secondary = SecondaryCat;
        this.size = SizeCat;
        this.Instances = new HashMap<Integer, ItemInstance>();
        this.costPrices = new ArrayList<ItemCostPrice>();
    }

    //Getters:
    public int getItemplateID() {
        return this.itemplateID;
    }

    public String getItemName() {
        return this.itemName;
    }

    public String getProducerName() {
        return this.producerName;
    }

    public int getStorageAmount() {
        return this.storageAmount;
    }

    public int getShelfAmount() {
        return this.shelfAmount;
    }

    public int getTotalAmount() {
        return this.totalAmount;
    }

    public double getSalePrice() {
        return this.salePrice;
    }

    public int getMinAmount() {
        return this.minAmount;
    }

    public Category getPrimaryCat() {
        return this.primary;
    }

    public Category getSecondaryCat() {
        return this.secondary;
    }

    public Category getSize() {
        return this.size;
    }

    public double getCostPrice(LocalDate date) {
        for (ItemCostPrice icp : this.costPrices) {
            if (icp.getEndDate() == null) { //reach to end
                if (date.isBefore(icp.getStartDate()))//reached to end and no date match = given date is before first order
                    return -2;
                return icp.getCP();
            }
            if (date.isEqual(icp.getStartDate()) || date.isEqual(icp.getEndDate()) || //inRange
                    (date.isAfter(icp.getStartDate()) && date.isBefore(icp.getEndDate())))
                return icp.getCP();
        }
        return -1; //product has not been ordered yet.
    }

    public int[] getAllItemIDs() {
        int[] res = new int[this.totalAmount]; //int [] cause size is known
        int i = 0;
        for (Map.Entry<Integer, ItemInstance> entry : this.Instances.entrySet()) {
            res[i] = entry.getValue().getItemID();
            i++;
        }
        return res;
    }

    public List<Integer> getAllExpired(LocalDate checkDate) {
        List<Integer> res = new ArrayList<>();
        for (Map.Entry<Integer, ItemInstance> entry : this.Instances.entrySet()) {
            ItemInstance toCheck = entry.getValue();
            if (toCheck.getExpiryDate().isBefore(checkDate))
                res.add(toCheck.getItemID());
        }
        return res;
    }

    public List<Integer> getAllDefectives() {
        List<Integer> res = new ArrayList<>();
        for (Map.Entry<Integer, ItemInstance> entry : this.Instances.entrySet()) {
            ItemInstance toCheck = entry.getValue();
            if (toCheck.isDefective())
                res.add(toCheck.getItemID());
        }
        return res;
    }


    //Setters/Adders:
    public Status setSalePrice(double sp) {
        this.salePrice = sp;
        return Status.Success;
    }

    public Status setMinAmount(int amount) {
        this.minAmount = amount;
        this.minAmChecker();
        return Status.Success;
    }

    public int[] addItems(int amount, LocalDate expiryD, LocalDate arriveD, String location, double cost) {
        int[] res = new int[amount]; //no need List cause size is known and no second use.
        for (int i=0; i < amount; i++) {
            ItemInstance toAdd = new ItemInstance(location, expiryD); //can assume all items in same shipment have same expiry date (forum).
            int new_id = toAdd.getItemID(); //get given id
            res[i] = new_id; //put in res (returns to end user)
            this.Instances.put(new_id, toAdd); //update in Instances map
            //update counters
            if (location.equals("Storage"))
                this.storageAmount++;
            else
                this.shelfAmount++;
            this.totalAmount++;
        }
        setNewCP(arriveD, cost, amount); //setting and saving order cost price.
        return res;
    }

    public Status removeItem(int ItemID) {
        ItemInstance toCheck = this.Instances.remove(ItemID); //returns item+deleting it from map if exist
        if (toCheck == null)
            return Status.Failure; //marks ID doesn't exist
        if (toCheck.getLocation().equals("Storage")) //updates storage/shelf amounts
            this.storageAmount--;
        else
            this.shelfAmount--;
        this.totalAmount--; //update total amount and check if reached to minAmount
        this.minAmChecker();
        return Status.Success; //marks found and Deleted.
    }

    public Status storageToShelf(int ItemID) {
        ItemInstance toCheck = this.Instances.get(ItemID);
        if (toCheck == null || !(toCheck.getLocation().equals("Storage")))
            return Status.Failure; //marks not exits in Storage
        this.storageAmount--;
        this.shelfAmount++;
        //no need to adjust&check total amount cause only location changes.
        return Status.Success;
    }

    public Status setDefectiveItem(int ItemID) {
        ItemInstance toCheck = this.Instances.get(ItemID); //returns item / null
        if (toCheck == null)
            return Status.Failure; //marks ID doesn't exist
        //else, updates item to defective (even if already defective)
        return toCheck.setDefective();
    }


    //Helper methods:
    private Status setNewCP(LocalDate date, double cPrice, int amount) {
        /*date will use as last costPrice endDate and new costPrice startDate, with that logic, each endDate of new
        costPrice is set to null first, then updates when there is a new costPrice. */
        if (!this.costPrices.isEmpty()) //if there is previous date to update
            this.costPrices.getLast().setEndDate(date);

        ItemCostPrice toAdd = new ItemCostPrice(cPrice, date, null, amount);
        this.costPrices.add(toAdd);
        return Status.Success;
    }

    private void minAmChecker() {
        //helper method in order to check and inform minAmount-totalAmount status when there is amount change.
        if (this.totalAmount <= this.minAmount) {
            System.out.println("Product: " + this.itemName + " ID:" + this.itemplateID + " has reached minimum amount");
        }
    }

    public boolean belongsToCat(String catName) {
        return (this.primary.getName().equals(catName) || this.secondary.getName().equals(catName) ||
                this.size.getName().equals(catName));
    }
}
