package endToEnd;

import DataInventory.*;
import DomainInventory.*;
import ServiceInventory.*;
import SetUp.SystemInitializer;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class endToEnd {

    @Test
    void testFullSystemInitialization_endToEnd() {
        // Arrange: create repositories and services
        IOrderRepository orderRepo = new OrderRepository();
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();

        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);
        OrderService orderService = new OrderService(orderRepo, productRepo, supplierRepo,supplierService);

        SystemInitializer initializer = new SystemInitializer(supplierService, orderService);

        // Act: initialize the system
        initializer.initializeSystem();

        // Assert:

        // 1. Check that 10 suppliers are created
        List<Integer> suppliers = supplierService.getActiveSuppliers();
        assertEquals(10, suppliers.size(), "There should be exactly 10 suppliers created");

        // 2. Check that each supplier has at least one agreement
        for (int supplierId : suppliers) {
            Supplier supplier = supplierRepo.pullSupplier(supplierId);
            assertFalse(supplier.getAllAgreements().isEmpty(),
                    "Each supplier should have at least one agreement");
        }

        // 3. Check that at least one supplier has products
        boolean foundProduct = false;
        for (int supplierId : suppliers) {
            Supplier supplier = supplierRepo.pullSupplier(supplierId);
            if (!supplier.getProductsMap().isEmpty()) {
                foundProduct = true;
                break;
            }
        }
        assertTrue(foundProduct, "There should be products assigned to suppliers");

        // 4. (תוקן) אין בדיקה ישירה של כל המוצרים כי אין getAllProducts()

        // 5. Check that 10 orders were created
        List<Order> orders = orderRepo.getAllActiveOrders();
        assertEquals(10, orders.size(), "There should be exactly 10 orders created");

        // 6. Check that each order has at least one product
        for (Order order : orders) {
            assertTrue(order.getOrderPrice() > 0,
                    "Each order should contain at least one product with positive price");
        }

        // 7. Check that the supplier of each order exists
        for (Order order : orders) {
            int supplierId = order.getOrderSupplierID();
            assertNotNull(supplierRepo.getSupplier(supplierId),
                    "Supplier for order should exist in the system");
        }

        // 8. Extra: Initialize again to verify no crash (optional)
        assertDoesNotThrow(() -> initializer.initializeSystem(),
                "Reinitializing should not crash the system");
    }
}
