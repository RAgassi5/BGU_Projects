package Domain;

public class Truck extends Vehicle {


    public Truck(int licenseNum) {
        super(licenseNum, 100, 150);
    }


    @Override
    public String getVehicleType() {
        return "Truck";
    }
}
