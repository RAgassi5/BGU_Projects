package Service;

public class LocationManager {
}
