package Domain;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Shipment {
    private static int ID = 1;
    private int id;
    private s_status shipmentStatus;
    private Location originLocation;
    private Location destinationLocation;
    private LocalDate shipmentDate;
    private LocalTime departureTime;
    private ArrayList<Product> productsInShipment;

    public Shipment(Location originLocation, Location destinationLocation,LocalDate shipmentDate) {
        this.id = ID++;
        this.originLocation = originLocation;
        this.destinationLocation = destinationLocation;
        this.shipmentStatus = s_status.PENDING;
        this.shipmentDate = shipmentDate;
        this.productsInShipment = new ArrayList<>();

    }

    /**
     * a getter function for a shipment's ID
     *
     * @return shipment's ID
     */
    public int getId() {
        return id;
    }

    /**
     * a function that update the shipment's status
     *
     * @param status current status of shipment
     */
    public void updateStatus(s_status status) {
        this.shipmentStatus = status;
    }

    /**
     * a getter function for the shipment's status
     *
     * @return an instance of s_status
     */
    public s_status getStatus() {
        return this.shipmentStatus;
    }

    /**
     * a getter function for a shipment's origin location
     *
     * @return an instance of Location
     */
    public Location getOriginLocation() {
        return this.originLocation;
    }

    /**
     * a getter function for a shipment's origin location
     *
     * @return an instance of Location
     */
    public Location getDestinationLocation() {
        return this.destinationLocation;
    }

    /**
     * a setter function for a shipment's departure time
     * the time is set for once the shipment is shipped
     */
    //TODO: maybe change!!
    public void setDepartureTime() {
        departureTime = LocalTime.now();
    }

    /**
     * a gettter function for a shipment's date
     *
     * @return a LocalDate
     */
    public LocalDate getShipmentDate() {
        return this.shipmentDate;
    }

    /**
     * a function that adds a new product to a shipment
     * @param product a product to add
     * @param quantity amount of the added product
     */
    public void addProductToShipment(Product product, int quantity) {
        product.setAmount(quantity);
        this.productsInShipment.add(product);
    }

    /**
     * a function that removes a product from a shipment
     * @param product the product to remove
     */
    public void removeProductFromShipment(Product product) {
        this.productsInShipment.remove(product);
    }

    /**
     * @return a list of all products in a shipment
     */
    public ArrayList<Product> getProductsInShipment() {
        return this.productsInShipment;
    }

    /**
     * a function that takes off the amount of weight from the shipment
     *
     * @param product the product to reduce from
     * @param weight the amount of weight to take out
     */
    public void updateProductsInShipment(Product product, int weight) {
        this.productsInShipment.remove(product);
        product.takePortionFromProduct(weight);
        this.productsInShipment.add(product);
    }

    /**
     * a print function for all products in a shipment
     */
    public void printShipmentProducts(){
        for(Product product : this.productsInShipment){
            product.printProduct();
        }
    }

    /**
     * a getter function for a shipment's total weight
     * @return the total weight of the shipment
     */
    public int getShipmentWeight(){
        int totalWeight = 0;
        for(Product product : this.productsInShipment){
            totalWeight += product.calculateFullWeight();
        }
        return totalWeight;
    }
    public LocalTime getDepartureTime(){
        return this.departureTime;
    }
}
