    package DomainTests;

    import DomainInventory.Order;
    import DomainInventory.Product;
    import org.junit.jupiter.api.Test;
    import static org.junit.jupiter.api.Assertions.*;

    import java.util.Date;

    public class OrderTest {

        @Test
        void testOrderCreation() {
            // Check that a new order is created correctly
            Order order = new Order(1, "0501234567");

            assertEquals(1, order.getOrderSupplierID());
            assertEquals(0, order.getOrderPrice());
            assertFalse(order.getOrderStatus());
        }

        @Test
        void testAddProductToOrder_success() {
            // Check adding a new product to an order
            Order order = new Order(2, "0507654321");
            Product product = new Product(1000, 50.0, 2, "Tomatoes", "FactoryA", "Food");

            boolean added = order.addProductToOrder(product, 3,product.getPrice());

            assertTrue(added);
            assertEquals(150.0, order.getOrderPrice());
            assertTrue(order.checkIfProductInList(product.getProductID()));
        }

        @Test
        void testRemoveProductFromOrder() {
            // Check removing a product from the order
            Order order = new Order(4, "0506667777");
            Product product = new Product(1002, 20.0, 4, "Soap", "FactoryC", "Cleaning");

            order.addProductToOrder(product, 4,product.getPrice());
            order.removeProductFromOrder(product.getProductID());

            assertFalse(order.checkIfProductInList(product.getProductID()));
        }

        @Test
        void testEditItemQuantity_updatesTotalPriceCorrectly() {
            // Check that editing product quantity updates total price
            Order order = new Order(5, "0505554444");
            Product product = new Product(1003, 15.0, 5, "Beer", "FactoryA", "Drink");

            order.addProductToOrder(product, 2,product.getPrice()); // 30₪
            order.editItemQuantity(5, product.getProductID()); // 75₪

            assertEquals(75.0, order.getOrderPrice());
            assertEquals(5, order.getProductQuantity(product.getProductID()));
        }

        @Test
        void testSetOrderStatus() {
            // Check that order status changes to true (completed)
            Order order = new Order(6, "0503332222");

            assertFalse(order.getOrderStatus());
            order.setOrderStatus();
            assertTrue(order.getOrderStatus());
        }

        @Test
        void testEditContactPhoneNumber() {
            // Check editing the contact phone number (only that it does not crash)
            Order order = new Order(7, "0501110000");

            order.editContactPhoneNumber("0509990000");

            assertDoesNotThrow(() -> System.out.println(order));
        }

        @Test
        void testSetAndGetOrderDates() {
            // Check setting and getting order and receiving dates
            Order order = new Order(8, "0502223333");
            Date now = new Date();

            order.setOrderDate(now);
            order.setOrderReceivingDate(now);

            assertEquals(now, order.getOrderDate());
            assertEquals(now, order.getOrderReceivingDate());
        }

        @Test
        void testRemoveItemFromOrder() {
            // Check removing an item directly
            Order order = new Order(9, "0501231234");
            Product product = new Product(1004, 40.0, 9, "Milk", "FactoryB", "Food");

            order.addProductToOrder(product, 2,product.getPrice());
            Order.orderItem item = order.findOrderItem(product.getProductID());

            boolean removed = order.removeItemFromOrder(item);

            assertTrue(removed);
            assertFalse(order.checkIfProductInList(product.getProductID()));
        }

        @Test
        void testFindOrderItem_whenExists() {
            // Check finding an existing order item
            Order order = new Order(10, "0504564564");
            Product product = new Product(1005, 60.0, 10, "Shampoo", "FactoryC", "Cleaning");

            order.addProductToOrder(product, 1,product.getPrice());

            assertNotNull(order.findOrderItem(product.getProductID()));
        }

        @Test
        void testFindOrderItem_whenNotExists() {
            // Check that finding a non-existing order item returns null
            Order order = new Order(11, "0507897897");

            assertNull(order.findOrderItem(9999));
        }
    }
