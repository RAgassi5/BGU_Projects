package PresentationInventory;

import ServiceInventory.OrderService;
import ServiceInventory.SupplierService;
import SetUp.SystemInitializer;
import DataInventory.*;

import java.util.Scanner;

public class ViewManger {
    static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        boolean run = true;
        IProductRepository productRepo = new ProductRepository();
        ISupplierRepository supplierRepo = new SupplierRepository();
        IOrderRepository orderRepo = new OrderRepository();


        SupplierService supplierService = new SupplierService(productRepo, supplierRepo);
        OrderService orderService = new OrderService(orderRepo, productRepo, supplierRepo,supplierService);


        OrderUI orderUI = new OrderUI(orderService,supplierService);
        SupplierUI supplierUI = new SupplierUI(supplierService);



        SystemInitializer initializer = new SystemInitializer(supplierService, orderService);


        while (run) {
            System.out.println("Welcome to the suppliers managing system: ");
            System.out.println("Please choose an option: ");
            System.out.println("1. Manage Order");
            System.out.println("2. Manage Suppliers");
            System.out.println("3. Initialize system with test data");
            System.out.println("4. Exit");

            int choice = promptMenuChoice(3);

            switch (choice) {
                case 1:
                    orderUI.manageOrder();
                    break;
                case 2:
                    supplierUI.manageSupplier();
                    break;
                case 3:
                    initializer.initializeSystem();
                    break;
                case 4:
                    run = false;

            }
        }

    }
    static int promptForInt(String message) {
        System.out.println(message);
        int id = scanner.nextInt();
        scanner.nextLine();
        return id;
    }

    static int promptMenuChoice(int maxOption) {
        int choice = -1;
        while (true) {
            System.out.print("Enter choice (1-" + maxOption + "): ");
            String input = scanner.nextLine();
            try {
                choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= maxOption) return choice;
            } catch (NumberFormatException ignored) {}
            System.out.println("Invalid choice. Please try again.");
        }
    }




    }


