package DomainInventory;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public abstract class Agreement {
    static int counterAgreement = 1;
    private int agreementID;
    private int supplierID;
    private String paymentMethod;
    private Date paymentDate;
    private boolean agreementStatus;
    private Map<Integer,Double> productsPrices;
    private Map<Integer,Discount> productsDiscounts;

    // Constructor - initializes a new agreement with a supplier ID and payment method.
    // Automatically assigns a unique agreement ID.
    public Agreement(int supplierID, String paymentMethod) {
        agreementStatus = true;
        this.supplierID = supplierID;
        this.paymentMethod = paymentMethod;
        this.paymentDate = new Date();
        productsPrices = new HashMap<>();
        productsDiscounts = new HashMap<>();
        this.agreementID = counterAgreement++;
    }

    // Returns the type of agreement. Default is "agreement" (should be overridden in subclasses).
    public String getAgreementType(){return "agreement";}

    // Returns the current status of the agreement (true = active, false = inactive).
    public boolean getAgreementStatus() {return agreementStatus;}

    // Toggles the agreement status (active ↔ inactive).
    public void setAgreementStatus() {
        if (agreementStatus) agreementStatus = false;
        else agreementStatus = true;
    }

    // Returns the unique ID of the agreement.
    public int getAgreementID() {
        return agreementID;
    }

    // Returns the supplier ID associated with this agreement.
    public int getSupplierID() {
        return supplierID;
    }

    // Finds a discount by catalog ID if it exists, returns null otherwise.
    public Discount findDiscount(int catalogID){
        return productsDiscounts.get(catalogID);
    }

    // Adds a new product to the agreement (only saves its catalog ID and price).
    public void addNewProduct(Product product) {
        product.setAgreementType(getAgreementType());
        productsPrices.put(product.getCatalogID(),product.getPrice());}

    // Adds a discount for a specific catalog ID if not already discounted. Returns true if successful.
    public boolean addNewDiscount(int catalogID, double price, int quantity) {
        if(productsDiscounts.containsKey(catalogID)){
            return false;
        }
        Discount discount = new Discount(catalogID,quantity,price);
        productsDiscounts.put(catalogID, discount);
        return true;
    }

    // Checks if a product (by catalog ID) exists in the agreement.
    public boolean checkIfProductExists(int catalogID) {return productsPrices.containsKey(catalogID);}

    // Removes a product and any discount associated with it.
    public void removeProduct(int catalogID) {
        productsPrices.remove(catalogID);
        productsDiscounts.remove(catalogID);}

    // Retrieves the discount associated with a specific catalog ID, if it exists.
    public Discount getProductDiscount(int catalogID) {
        return productsDiscounts.get(catalogID);
    }

    // Returns a string that represents all agreement details, including associated products and discounts.
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Agreement ID: ").append(agreementID).append("\n");
        sb.append("Supplier ID: ").append(supplierID).append("\n");
        sb.append("Payment Method: ").append(paymentMethod).append("\n");
        sb.append("Status: ").append(agreementStatus ? "Active" : "Inactive").append("\n");
        sb.append("Products:\n");
        for (Map.Entry<Integer, Double> entry : productsPrices.entrySet()) {
            sb.append("  - Catalog ID: ").append(entry.getKey())
                    .append(" | Price: ").append(entry.getValue());

            Discount discount = productsDiscounts.get(entry.getKey());
            if (discount != null) {
                sb.append(" | Discount: ").append(discount);
            }
            sb.append("\n");
        }
        return sb.toString();
    }

}
