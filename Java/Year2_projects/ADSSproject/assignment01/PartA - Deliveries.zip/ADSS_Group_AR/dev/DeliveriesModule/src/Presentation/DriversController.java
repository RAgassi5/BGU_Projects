package Presentation;

import Service.DriversManager;

public class DriversController {
    private final DriversManager driversManager;

    public DriversController() {
        this.driversManager = DriversManager.getInstance();
    }

    public void addNewDriverToSystem(String driverName){
        this.driversManager.addDriver(driverName);
    }
    public void deleteDriveFromSystem(String driverName){
        this.driversManager.deleteDriver(driverName);
    }
    public void addLicenseToDriverInSystem(String driverName, String license){
        this.driversManager.setDriverLicense(driverName, license);
    }
    public void showAllDrivers(){
        this.driversManager.printAvailableDrivers();
    }

    public int getNumberOfDrivers(){
       return driversManager.getDriverCount();
    }
}
