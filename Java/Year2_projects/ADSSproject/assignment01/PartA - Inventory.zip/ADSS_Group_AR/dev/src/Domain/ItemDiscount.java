package Domain;

import java.time.LocalDate;

public class ItemDiscount extends ADiscount {
    //Fields:
    protected int templateID;

    //Constructor:
    public ItemDiscount(double rate, LocalDate sDate, LocalDate eDate, int ItempID) {
        super(rate, sDate, eDate);
        this.templateID = ItempID;
    }

    //Methods:

    @Override
    public boolean hasDiscount(ItemTemplate item) {
        return (this.templateID == item.getItemplateID());
    }
}
