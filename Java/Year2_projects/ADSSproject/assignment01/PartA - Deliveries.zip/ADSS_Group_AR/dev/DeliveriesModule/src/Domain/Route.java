package Domain;

import java.time.LocalDate;
import java.time.LocalTime;

public class Route {
    private class DrivingRoute {
        /**
         * a class representing a Node in a linked list
         */
        private class Node {
            private Shipment shipmentData;
            private Node nextNode;
            private Node prevNode;

            /**
             * a constructor for the Node class
             *
             * @param shipmentData the shipment to be added
             */
            public Node(Shipment shipmentData) {
                this.shipmentData = shipmentData;
            }

            /**
             * a getter function for the shipment data held inside the Node
             *
             * @return an instance of a Shipment
             */
            public Shipment getShipmentData() {
                return shipmentData;
            }

            /**
             * a setter function for the next Node
             *
             * @param nextNode the Node that will be placed next in order
             */
            public void setNextNode(Node nextNode) {
                this.nextNode = nextNode;
            }

            /**
             * a getter function for the next node
             *
             * @return an instance of a Node
             */
            public Node getNextNode() {
                return nextNode;
            }

            /**
             * a setter function for the previous Node
             *
             * @param prevNode the Node to be placed before the Node
             */
            public void setPrevNode(Node prevNode) {
                this.prevNode = prevNode;
            }

            /**
             * a getter function for the previous Node
             *
             * @return an instance of a Node
             */
            public Node getPrevNode() {
                return prevNode;
            }
        }

        private Node start;
        private Node end;
        private Node currentShipment;
        private int amountOfStops;

        public DrivingRoute() {
            this.amountOfStops = 0;
        }

        /**
         * a function that adds a stop along the route of the shipment vehicle
         *
         * @param shipmentData the Shipment to be added to the route
         */
        public void addStop(Shipment shipmentData) {
            Node stopToAdd = new Node(shipmentData);
            if (this.amountOfStops == 0) {
                this.start = stopToAdd;
                this.end = this.start;
                this.currentShipment = this.start;
            } else {
                Node currentNode = this.start;
                while (currentNode.getNextNode() != null) {
                    currentNode = currentNode.getNextNode();
                }
                currentNode.setNextNode(stopToAdd);
                stopToAdd.setPrevNode(currentNode);
                this.end = stopToAdd;
            }
            this.amountOfStops++;
        }

        /**
         * a getter function for the shipment that is being delivered right now
         *
         * @return an instance of a Shipment that is being delivered right now
         */
        public Shipment getCurrentShipment() {
            return this.currentShipment.getShipmentData();
        }


        /**
         * a function that searches for a specific shipment in a route
         *
         * @param shipmentId the shipment's ID
         * @return boolean
         */

        public boolean searchForShipmentById(int shipmentId) {
            if (shipmentId <= 0) {
                return false;
            }
            Node currentNode = this.start;

            while (currentNode != null) {
                if (currentNode.shipmentData.getId() == shipmentId) {
                    return true;
                } else {
                    currentNode = currentNode.getNextNode();
                }
            }
            return false;
        }

        /**
         * a getter function for a specific function
         *
         * @param shipmentId the id of the wanted shipment
         * @return the looked for shipment
         */
        public Shipment getShipmentById(int shipmentId) {
            if (shipmentId <= 0) {
                return null;
            }
            Node currentNode = this.start;
            while (currentNode != null) {
                if (currentNode.shipmentData.getId() == shipmentId) {
                    return currentNode.getShipmentData();
                }
                currentNode = currentNode.getNextNode();
            }
            return null;
        }

        /**
         * a setter function for the route status
         *
         * @param status the shipment's status
         */
        public void updateAllShipmentsStatusInRoute(s_status status) {
            Node currentNode = this.start;
            while (currentNode != null) {
                currentNode.shipmentData.updateStatus(status);
                currentNode = currentNode.getNextNode();
            }
        }

        /**
         * a getter function for the driving route's total weight
         *
         * @return the total weight
         */
        public int getTotalWeight() {
            int routeTotalWeight = 0;
            Node currentNode = this.start;
            while (currentNode != null) {
                routeTotalWeight += currentNode.shipmentData.getShipmentWeight();
                currentNode = currentNode.getNextNode();
            }
            return routeTotalWeight;
        }

        /**
         * a function that returns the route's status
         *
         * @return the route's current status
         */
        public s_status getStatus() {
            return this.start.shipmentData.getStatus();
        }

        /**
         * a function that prints all products in a route
         */
        public void printAllRouteProducts() {
            Node currentNode = this.start;
            while (currentNode != null) {
                System.out.println("Shipment " + currentNode.getShipmentData().getId() + " current weight: " + currentNode.shipmentData.getShipmentWeight());
                System.out.println("\n=== Products in shipment " + currentNode.shipmentData.getId() + " ===");
                currentNode.shipmentData.printShipmentProducts();
                currentNode = currentNode.getNextNode();
            }
        }

        /**
         * a function that sets all shipment's departure time
         */
        public void setDepTime(){
            Node currentNode = this.start;
            while (currentNode != null) {
                currentNode.getShipmentData().setDepartureTime();
                currentNode = currentNode.getNextNode();
            }
        }
        public LocalTime getDepartureTime() {
            return this.start.getShipmentData().getDepartureTime();
        }

    }

    private DrivingRoute CurrentdrivingRoute;
    private Driver currentDriver;
    private Vehicle currentVehicle;
    private District currentShipmentDistrict;
    private LocalDate routeDate;

    public Route() {
        this.CurrentdrivingRoute = new DrivingRoute();
        this.currentDriver = null;
        this.currentVehicle = null;
    }

    /**
     * a fucntion that adds a shipment to the current Route
     *
     * @param shipmentData the shipment to be added
     */
    public void addShipment(Shipment shipmentData) {
        //TODO: check if needed!
        if (this.CurrentdrivingRoute.amountOfStops == 0) {
            this.currentShipmentDistrict = shipmentData.getOriginLocation().getDistrict();
            this.routeDate = shipmentData.getShipmentDate();
        }
        this.CurrentdrivingRoute.addStop(shipmentData);
    }

    /**
     * a function that adds a new Driver to a Route
     *
     * @param driver an instance of the Driver to be added
     */
    public void addDriver(Driver driver) {
        this.currentDriver = driver;
    }

    /**
     * a getter function for a route's Driver
     *
     * @return the route's driver
     */
    public Driver getDriver() {
        return this.currentDriver;
    }


    /**
     * a function that adds a new Vehicle to a Route
     *
     * @param vehicleInstance an instance of shipment vehicle
     */
    public void addVehicle(Vehicle vehicleInstance) {
        this.currentVehicle = vehicleInstance;

    }

    /**
     * a getter function for the route's vehicle
     *
     * @return the route's vehicle
     */
    public Vehicle getVehicle() {
        return this.currentVehicle;
    }

    /**
     * a getter function for a route's vehicle license number
     *
     * @return the vehicle's license number
     */
    public int getRouteVehicleLicense() {
        return this.currentVehicle.getLicenseNumber();
    }

    /**
     * a getter function for the Route's district
     *
     * @return District
     */
    public District getCurrentDistrict() {
        return this.currentShipmentDistrict;
    }

    /**
     * a function that returns the length of the current route
     *
     * @return the length of the route
     */
    public int getRouteLength() {
        return this.CurrentdrivingRoute.amountOfStops;
    }

    /**
     * a getter function for the route's date
     *
     * @return LocalDate
     */
    public LocalDate getRouteDate() {
        return this.routeDate;
    }

    /**
     * a getter function for a specific shipment by its ID
     *
     * @param shipmentId the shipment's ID to be searched for
     * @return looked for Shipment
     */
    public Shipment getShipmentInRoute(int shipmentId) {
        if (!this.CurrentdrivingRoute.searchForShipmentById(shipmentId)) {
            return null;
        }
        return this.CurrentdrivingRoute.getShipmentById(shipmentId);
    }

    /**
     * a setter function for each shipment in the current Route
     *
     * @param status the shipment's status
     */
    public void updateRouteStatus(s_status status) {
        this.CurrentdrivingRoute.updateAllShipmentsStatusInRoute(status);

    }

    /**
     * a getter function for the route's status
     *
     * @return the route's status
     */
    public s_status getStatus() {
        return this.CurrentdrivingRoute.getStatus();
    }


    /**
     * a getter function for the route's weight
     *
     * @return the total weight of the current route
     */
    public int getRouteWeight() {
        return (this.CurrentdrivingRoute.getTotalWeight());
    }

    /**
     * a function that updates a shipment's products in a route
     *
     * @param ShipmentId the shipment to be updated
     * @param product    the product to update
     * @param weight     the weigh to take out
     */
    public void updateRouteProducts(int ShipmentId, Product product, int weight) {
        Shipment toUpdate = this.CurrentdrivingRoute.getShipmentById(ShipmentId);
        if (toUpdate != null) {
            toUpdate.updateProductsInShipment(product, weight);
        }

    }
    /**
     * a print function for all products in a route
     */
    public void printRouteProducts() {
        this.CurrentdrivingRoute.printAllRouteProducts();
    }

    public void setDepartureTimeForAllShipments(){
        this.CurrentdrivingRoute.setDepTime();
    }
    public LocalTime getDepartureTimeForAllShipments() {
        return this.CurrentdrivingRoute.getDepartureTime();
    }
}
