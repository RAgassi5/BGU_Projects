package Service;

import Domain.Truck;
import Domain.Van;
import Domain.Vehicle;
import Domain.vehicle_status;

import java.util.Hashtable;

public class VehiclesManager {
    private Hashtable<Integer, Vehicle> availableVehicles;
    private static VehiclesManager currentVehiclesManager;

    private VehiclesManager() {
        availableVehicles = new Hashtable<>();
    }

    public static VehiclesManager getInstance() {
        if (currentVehiclesManager == null) {
            currentVehiclesManager = new VehiclesManager();
        }
        return currentVehiclesManager;
    }

    public void addVehicle(String vehicleType, int vehicleNum) {
        if (!vehicleType.equals("Truck") && !vehicleType.equals("Van")) {
            throw new IllegalArgumentException("Invalid vehicle type");
        } else if (vehicleNum < 1) {
            throw new IllegalArgumentException("Invalid vehicle number");

        } else {
            if (vehicleType.equals("Truck")) {
                Truck truck = new Truck(vehicleNum);
                this.availableVehicles.put(vehicleNum, truck);
                System.out.println("Truck number: " + vehicleNum + " was added to the system successfully!");
            }
            if (vehicleType.equals("Van")) {
                Van van = new Van(vehicleNum);
                this.availableVehicles.put(vehicleNum, van);
                System.out.println("Van number: " + vehicleNum + " was added to the system successfully!");
            }
        }
    }
    public void removeVehicle(int vehicleNum) {
        if(this.availableVehicles.remove(vehicleNum) == null) {
            System.out.println("Vehicle does not exist in the system");
        }else {
            System.out.println("Vehicle number: " + vehicleNum + " has been removed successfully!" );
        }
    }

    public Vehicle assignVehicle(int totalWeightNeededToTransfer) {
        for (Vehicle vehicle : this.availableVehicles.values()) {
            if(vehicle.getVehicleMaxCapacity() > totalWeightNeededToTransfer) {
                vehicle.setCurrentStatus(vehicle_status.WORKING);
                return vehicle;
            }
        }
        return null;
    }
    public void printAllVehicles() {
        for (Vehicle vehicle : this.availableVehicles.values()) {
            vehicle.printVehicle();
        }
    }
    public int getAmountOfVehicles() {
        return this.availableVehicles.size();
    }
}
