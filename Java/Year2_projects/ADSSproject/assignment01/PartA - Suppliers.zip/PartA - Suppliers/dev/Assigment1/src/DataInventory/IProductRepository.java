package DataInventory;

import DomainInventory.Product;

import java.util.ArrayList;
import java.util.HashMap;
// Interface for managing Product objects
public interface IProductRepository {
    // Get a product by product ID and supplier ID
    public Product getProductByPSId(int ProductId,int supplierID);
    // Get a map of products matching a product ID
    public HashMap<Integer, Product> getProductByProductId(int ProductId);
    // Get the product ID by searching with product name
    public int getProductIDByProductName(String ProductName);
    // Add a new product to the repository
    public void addProductToRepo(Product product);
    // Remove a product from the repository
    public void deleteProductFromRepo(Product product);

}
