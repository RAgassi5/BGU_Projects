package Domain;

import java.time.LocalDate;

public class CategoryDiscount extends ADiscount {
    //Fields:
    protected String categoryName;

    //Constructor:
    public CategoryDiscount(double rate, LocalDate sDate, LocalDate eDate, String categoryName) {
        super(rate, sDate, eDate);
        this.categoryName = categoryName;
    }

    //Methods:

    @Override
    public boolean hasDiscount(ItemTemplate item) {
        return (this.categoryName.equals(item.getPrimaryCat().getName()) ||
                this.categoryName.equals(item.getSecondaryCat().getName()) ||
                this.categoryName.equals(item.getSize().getName()));
    }
}
