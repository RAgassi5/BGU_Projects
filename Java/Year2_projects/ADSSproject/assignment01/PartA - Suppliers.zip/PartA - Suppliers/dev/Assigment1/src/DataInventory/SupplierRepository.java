package DataInventory;

import DomainInventory.Supplier;

import java.util.ArrayList;
import java.util.HashMap;

public class SupplierRepository implements ISupplierRepository {
    private HashMap<Integer, Supplier> suppliersByID = new HashMap<>();

    @Override
    public void insertSupplier(Supplier supplier) {
        suppliersByID.put(supplier.getSupplierID(), supplier);
    }

    @Override
    public Supplier pullSupplier(int supplierID) {
        return suppliersByID.get(supplierID);
    }


    @Override
    public ArrayList<Supplier> getAllSuppliers() {
        ArrayList<Supplier> suppliers = new ArrayList<>();
        suppliers.addAll(suppliersByID.values());
        return suppliers;
    }


    @Override
    // Returns a list of supplier IDs that supply the given product ID.
    public ArrayList<Integer> getSuppliersByProductID(int productID) {
        ArrayList<Integer> supplierIDs = new ArrayList<>();
        for (HashMap.Entry<Integer, Supplier> entry : suppliersByID.entrySet()) {
            Supplier supplier = entry.getValue();
            if (supplier.hasProductWithID(productID)) {
                supplierIDs.add(entry.getKey()); // המפתח = supplierID
            }
        }
        return supplierIDs;
    }

    @Override
    public Supplier getSupplier(int supplierID) {
        return suppliersByID.get(supplierID);
    }
}


